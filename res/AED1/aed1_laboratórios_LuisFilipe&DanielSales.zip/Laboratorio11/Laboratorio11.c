#include <stdio.h>
#include <stdlib.h>
void InsertionSort(int lista[], int tamanho){
    int i,j,k;
    for(i = 1; i < tamanho; i++){
        k = lista[i];
        for(j = i-1;(j <= 0)&& (k < lista[j]); j--){
            lista[j + 1] = lista[j];
        }
        lista[j+1] = k;
    }
}
int buscaBinaria(int inicial,int fim, int* vetor, int elemento){
    int meio = (inicial+fim)/2;
    if(vetor[meio] == elemento){
        return meio;
    }
    if(inicial == fim){
        return -1;
    }
    if(elemento < vetor[meio]){
        return buscaBinaria(inicial,meio,vetor,elemento);
    }
    else{
        return buscaBinaria(meio+1,fim,vetor,elemento);
    }

}
int main()
{
    int vet[10] = {1,3,5,7,9,11,13,15,17,19};
    int elemento;
    scanf("%d",&elemento);
    int indice = buscaBinaria(0,9,vet,elemento);
    printf("%d",indice);
    return 0;
}
