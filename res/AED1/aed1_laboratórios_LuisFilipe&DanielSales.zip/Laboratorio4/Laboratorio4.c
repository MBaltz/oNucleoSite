#include <stdio.h>
#include <stdlib.h>
void insertionSort(int original[], int tamanho) {
	int i, j, atual;
	for (i = 1; i < tamanho; i++) {
		atual = original[i];
		for (j = i - 1; (j >= 0) && (atual < original[j]); j--) {
			original[j + 1] = original[j];
        }
		original[j+1] = atual;
	}

}
int main()
{
    int vetor1[5] = {8, 2, 5, 1, 3};
    int vetor2[5] = {&vetor1[0], &vetor1[1], &vetor1[2], &vetor1[3], &vetor1[4]};
    insertionSort(vetor2, 5);
    printf("%d ", vetor2[0]);
    printf("%d ", vetor2[1]);
    printf("%d ", vetor2[2]);
    printf("%d ", vetor2[3]);
    printf("%d.", vetor2[4]);
    return 0;
}
