#include <stdio.h>
#include <stdlib.h>

int interagir(int *v,int inicio,int fim){
    int pivo = fim;
    int i = inicio;
    int j;
    int aux;

    for (j = inicio; j < fim; j++){
        if (v[j] < v[pivo]){
            aux = v[i];
            v[i] = v[j];
            v[j] = aux;

            i++;
        }
    }
    aux = v[i];
    v[i] = v[pivo];
    v[pivo] = aux;

    return i;
}

void quickSort(int *v, int inicio, int fim){

    if ( fim > inicio){
        int p = interagir(v, inicio, fim);
        quickSort(v, inicio, p-1);
        quickSort(v, inicio+1, fim);
    }
}

int main()
{
    int v[] = {5, 1, 4, 2, 3};

    quickSort(v, 0, 4);
    int k;
    for (k = 0; k<=4; k++)
        printf("%d ",v[k]);
    printf("\n");
    return 0;
}
