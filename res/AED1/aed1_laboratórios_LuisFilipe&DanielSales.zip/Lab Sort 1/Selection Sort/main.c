#include <stdio.h>
#include <stdlib.h>

// atual e a chave

void selectionSort (int lista[], int tamanho){
    int i, j, menor,posicaoMenor,maior,posicaoMaior;
    for (i = 0; i < tamanho/2; i++){
            menor = lista[i];
            posicaoMenor = i;
            posicaoMaior = tamanho-1-i;
            maior = lista[posicaoMaior];
        for (j = i; j < tamanho-i; j++){
            if (menor > lista[j]){
                menor = lista[j];
                posicaoMenor = j;
            }
            if (maior < lista[j]){
                posicaoMaior = j;
                maior = lista[j];
            }
        }
        if (i+1 == tamanho/2){
            if (lista[i] > lista[i+1]){
                int u = lista[i];
                lista[i] = lista[i+1];
                lista[i+1] = u;
            }
        }
        else{
        lista[posicaoMaior] = lista[tamanho-1-i];
        lista[tamanho-1-i] = maior;
        lista[posicaoMenor] = lista[i];
        lista[i] = menor;
        }
    }
}
void imprimir (int *lista,int tamanho){
    int k;
    for (k = 0; k < tamanho; k++){
        printf("%d ", lista[k]);
    }
    printf("\n");
}
int main()
{
    int l[] = {4,5,6,2,10,19,65,3,0,1};
    imprimir(l,10);
    selectionSort(l,10);
    imprimir(l,10);
    return 0;
}
