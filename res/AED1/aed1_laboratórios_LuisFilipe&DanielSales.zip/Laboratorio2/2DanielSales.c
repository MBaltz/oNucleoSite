#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero;
    int c;
    scanf("%d", &numero);
    int resposta = (numero + 1);
    for(c = 1; c < resposta; c++){
        if(numero%c == 0){
            printf("%d ", c);
        }
    }
    return 0;
}
