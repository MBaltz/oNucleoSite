#include <stdio.h>
#include <stdlib.h>


void criarHeap (int* v,int fim){
    int paiInicial = (fim-1)/2;
    int pai = paiInicial;
    int maiorFilho;
    int aux;
    while (pai >= 0 && fim > 0){
        if (pai > paiInicial){
            pai = paiInicial;
        }
        if(pai*2+2 > fim){
            maiorFilho = (pai*2)+1;
        }
        else if(v[pai*2+2] >= v[pai*2+1]){
            maiorFilho = (pai*2+2);
        }
        else{
            maiorFilho = (pai*2+1);
        }
        if (v[pai] < v[maiorFilho]){
            aux = v[maiorFilho];
            v[maiorFilho] = v[pai];
            v[pai] = aux;
            pai = maiorFilho;
        }
        else{
            pai--;
        }
    }
}
void heapSort(int *vetor, int fim){
    int aux;
    criarHeap(vetor, fim);
    while(fim > 0){
        aux = vetor[fim];
        vetor[fim] = vetor[0];
        vetor[0] = aux;
        fim--;
        criarHeap(vetor, fim);
    }
}

int main()
{
    int vetor[] = {5, 41, 3, 1, -7, 6, 2, 4, 0};
    heapSort(vetor, 6);
    int i;
    for(i = 0; i < 7; i++){
        printf("%d \n", vetor[i]);
    }
    return 0;
}
