#include <stdio.h>
#include <stdlib.h>

int main()
{
    int primeiro,segundo,terceiro;
    scanf("%d",&primeiro);
    scanf("%d",&segundo);
    scanf("%d",&terceiro);
    if((primeiro > segundo)&&(segundo > terceiro))
        {
            printf("%d, ", terceiro);
            printf("%d, ", segundo);
            printf("%d.\n", primeiro);
    }
    if((primeiro > terceiro)&&(terceiro > segundo))
            {
            printf("%d, ", segundo);
            printf("%d, ", terceiro);
            printf("%d.\n", primeiro);
    }
    if((segundo > terceiro)&&(terceiro > primeiro))
            {
            printf("%d, ", primeiro);
            printf("%d, ", terceiro);
            printf("%d.\n", segundo);
    }
    if((segundo > primeiro)&&(primeiro > terceiro))
            {
            printf("%d, ", terceiro);
            printf("%d, ", primeiro);
            printf("%d.\n", segundo);
    }
    if((terceiro > primeiro)&&(primeiro > segundo))
            {
            printf("%d, ", segundo);
            printf("%d, ", primeiro);
            printf("%d.\n", terceiro);
    }
    if((terceiro > segundo)&&(segundo > primeiro)){
        printf("%d, ", primeiro);
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
    }
    else{
        printf("%d, ", primeiro);
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
    }
    if((primeiro >= 0)&&(segundo >= 0)&&(terceiro >= 0)){
        printf("positivos: ");
        printf("%d, ", primeiro);
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
        printf("negativos: ");
        printf("Nenhum.\n");
    }
    if((primeiro >= 0)&&(segundo >= 0)&&(terceiro < 0)){
        printf("positivos: ");
        printf("%d, ", primeiro);
        printf("%d.\n", segundo);
        printf("negativos: ");
        printf("%d.\n", terceiro);
    }
    if((primeiro >= 0)&&(segundo < 0)&&(terceiro >= 0)){
        printf("positivos: ");
        printf("%d, ", primeiro);
        printf("%d.\n", terceiro);
        printf("negativos: ");
        printf("%d.\n", segundo);
    }
    if((primeiro < 0)&&(segundo >= 0)&&(terceiro >= 0)){
        printf("positivos: ");
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
        printf("negativos: ");
        printf("%d.\n", primeiro);
    }
    if((primeiro < 0)&&(segundo < 0)&&(terceiro >= 0)){
        printf("positivos: ");
        printf("%d.\n", terceiro);
        printf("negativos: ");
        printf("%d, ", primeiro);
        printf("%d.\n", segundo);
    }
    if((primeiro >= 0)&&(segundo < 0)&&(terceiro < 0)){
        printf("positivos: ");
        printf("%d.\n", primeiro);
        printf("negativos: ");
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
    }
    if((primeiro < 0)&&(segundo >= 0)&&(terceiro < 0)){
        printf("positivos: ");
        printf("%d.\n", segundo);
        printf("negativos: ");
        printf("%d, ", primeiro);
        printf("%d.\n", terceiro);
    }
    if((primeiro < 0)&&(segundo < 0)&&(terceiro < 0)){
        printf("positivos: ");
        printf("Nenhum.\n");
        printf("negativos: ");
        printf("%d, ", primeiro);
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
    }
    if ((primeiro%2 == 0)&&(segundo%2==0)&&(terceiro%2 == 0)){
        printf("pares: ");
        printf("%d, ", primeiro);
        printf("%d ,", segundo);
        printf("%d.\n", terceiro);
        printf("impares: ");
        printf("Nenhum.");
    }
    if (((primeiro%2 == 1)||(primeiro%2 == -1))&&(segundo%2==0)&&(terceiro%2 == 0)){
        printf("pares: ");
        printf("%d, ", segundo);
        printf("%d.\n", terceiro);
        printf("impares: ");
        printf("%d.", primeiro);
    }
    if ((primeiro%2 == 0)&&((segundo%2==1)||(segundo%2 == -1))&&(terceiro%2 == 0)){
        printf("pares: ");
        printf("%d, ", primeiro);
        printf("%d.\n", terceiro);
        printf("impares: ");
        printf("%d.", segundo);
    }
    if ((primeiro%2 == 0)&&(segundo%2==0)&&((terceiro%2 == 1)||(terceiro%2 == -1))){
        printf("pares: ");
        printf("%d, ", primeiro);
        printf("%d.\n", segundo);
        printf("impares: ");
        printf("%d.", terceiro);
    }
    if (((primeiro%2 == 1)||(primeiro%2 == -1))&&((segundo%2==1)||(segundo%2 == -1))&&(terceiro%2 == 0)){
        printf("pares: ");
        printf("%d.\n", terceiro);
        printf("impares: ");
        printf("%d, ", primeiro);
        printf("%d.", segundo);
    }
    if (((primeiro%2 == 1)||(primeiro%2 == -1))&&(segundo%2==0)&&((terceiro%2 == 1)||(terceiro%2 == -1))){
        printf("pares: ");
        printf("%d.\n", segundo);
        printf("impares: ");
        printf("%d, ", primeiro);
        printf("%d.", terceiro);
    }
    if ((primeiro%2 == 0)&&((segundo%2==1)||(segundo%2 == -1))&&((terceiro%2 == 1)||(terceiro%2 == -1))){
        printf("pares: ");
        printf("%d.\n", primeiro);
        printf("impares: ");
        printf("%d, ", segundo);
        printf("%d.", terceiro);
    }
    if (((primeiro%2 == 1)||(primeiro%2 == -1))&&((segundo%2==1)||(segundo%2 == -1))&&((terceiro%2 == 1)||(terceiro%2 == -1))){
        printf("pares: ");
        printf("Nenhum.\n");
        printf("impares: ");
        printf("%d, ", primeiro);
        printf("%d, ", segundo);
        printf("%d.", terceiro);
    }

    return 0;
}

