#include <stdio.h>
#include <stdlib.h>


typedef struct No{
    int valor;
    struct No *prox;
    struct No *ant;
}No;

typedef struct Lista{
    No *inicio;
}Lista;

Lista* iniciar(){
    Lista *l = malloc(sizeof(Lista));
    l->inicio = NULL;
    return l;
}


void insertionSort(Lista *l){
    No *i, *j, *jp;
    No *chave, *proximoI;
    for(i = l->inicio->prox; i != NULL; i = proximoI){
        //imprimir(l);
        chave = i;
        proximoI = chave->prox;
        j = i->ant;
        while (j != NULL && chave->valor < j->valor){
            j = j->ant;
        }
        if (j == NULL){
            if(chave->prox != NULL){
                chave->ant->prox = chave->prox;
                chave->prox->ant = chave->ant;
                l->inicio->ant = chave;
                chave->prox = l->inicio;
                chave->ant = NULL;
                l->inicio = chave;
            }
            else{
                chave->ant->prox = chave->prox;
                l->inicio->ant = chave;
                chave->prox = l->inicio;
                chave->ant = NULL;
                l->inicio = chave;
            }
        }
        else if(j->prox != chave){
            jp = j->prox;
            if (chave->prox != NULL){
                chave->ant->prox = chave->prox;
                chave->prox->ant = chave->ant;
                jp->ant = chave;
                chave->prox = jp;
                j->prox = chave;
                chave->ant = j;
            }
            else{
                chave->ant->prox = chave->prox;
                jp->ant = chave;
                chave->prox = jp;
                j->prox = chave;
                chave->ant = j;
            }
        }
    }
}

void adicionar(Lista *l, int valor){
    No *novo = malloc(sizeof(No));
    if(l->inicio != NULL){
        l->inicio->ant = novo;
        novo->prox = l->inicio;
        novo->ant = NULL;
        novo->valor = valor;
        l->inicio = novo;
    }
    else{
        l->inicio = novo;
        novo->prox = NULL;
        novo->ant = NULL;
        novo->valor = valor;
    }
}

void remover(Lista *l, int valor){
    if(l->inicio != NULL){
        No *p;
        No *escolhido = NULL;
        for(p = l->inicio; p != NULL; p = p->prox){
            if(p->valor == valor){
                escolhido = p;
            }
        }
        if(escolhido == NULL){
            printf("Valor nao encontrado");
        }
        else{
            if(escolhido->ant == NULL && escolhido->prox != NULL){
                escolhido->prox->ant = NULL;
                l->inicio = escolhido->prox;
                free(escolhido);
            }
            else if(escolhido->ant == NULL && escolhido->prox == NULL){
                l->inicio = NULL;
                free(escolhido);
            }
            else if(escolhido->prox == NULL){
                escolhido->ant->prox = NULL;
                free(escolhido);
            }
            else{
                escolhido->ant->prox = escolhido->prox;
                escolhido->prox->ant = escolhido->ant;
                free(escolhido);
            }
        }
    }
    else{
        printf("Lista vazia");
    }
}
void imprimir(Lista *l){
    No *p;
    for(p = l->inicio; p != NULL; p = p->prox){
        printf("%d ", p->valor);
    }
    printf("\n");
}

int main()
{
    Lista *l = iniciar();
    adicionar(l, 89);
    adicionar(l, 12);
    adicionar(l, 15);
    adicionar(l, 34);
    adicionar(l, 2);
    adicionar(l, 51);
    adicionar(l, 90);
    adicionar(l,0);
    imprimir(l);
    insertionSort(l);
    imprimir(l);
    return 0;
}
