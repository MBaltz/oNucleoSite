#include <stdio.h>
#include <stdlib.h>
float* escreverMatrizSimples(int linha, int coluna){
    float *matriz;
    int i;
    matriz = (float*)malloc(linha*coluna*sizeof(float));
    printf("Digite os valores da matriz a cada linha:\n");
    for(i = 0; i < (linha*coluna); i++){
        scanf("%f", &matriz[i]);
    }
    return matriz;
}
float* escreverMatrizPonteiro(int linha, int coluna){
    float **matriz;
    int i,j;
    matriz = (float**)malloc(linha*sizeof(float*));
    printf("Digite os valores da segunda matriz a cada linha: \n");
    for(i = 0; i < linha; i++){
        matriz[i] = (float*)malloc(coluna*sizeof(float));
        for (j=0; j<coluna;j++){
            scanf("%f",&matriz[i][j]);
        }
    }
    return matriz;
}
float* somaMatriz(float *matriz1,float **matriz2,int l,int c){
    int i,j;
    float **matrizf;
    matrizf = (float**)malloc(l*sizeof(float*));
    for (i=0;i<l;i++){
        matrizf[i] = (float*)malloc(c*sizeof(float));
        for (j=0;j<c;j++){
            matrizf[i][j] = (matriz2[i][j])+(matriz1[i*c+j]);
        }
    }
    return matrizf;
}
int main(){

    int linha, coluna;
    printf("Digite o numero de linhas:\n");
    scanf("%d", &linha);
    printf("Digite o numero de colunas:\n");
    scanf("%d", &coluna);
    float *matriz = escreverMatrizSimples(linha, coluna);
    float **matriz2 = escreverMatrizPonteiro(linha,coluna);
    int j,k,p;
    /*
    for(j = 0; j < (linha*coluna);j++){
        printf("%.2f\n", matriz[j]);
    }
    /*
    for(k = 0; k < linha; k++){
        for (p=0; p<coluna;p++){
            printf("%.2f\n",matriz2[k][p]);
        }
    }
    */
    float **matriz3 = somaMatriz(matriz,matriz2,linha,coluna);
    printf("A soma das matrizes e:\n");
    for(k = 0; k < linha; k++){
        for (p=0; p<coluna;p++){
            printf("%.2f\n",matriz3[k][p]);
        }
    }
    return 0;
}
