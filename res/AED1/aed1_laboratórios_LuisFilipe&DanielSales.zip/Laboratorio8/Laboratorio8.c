#include <stdio.h>
#include <stdlib.h>
struct lista{
    int info;
    struct lista*prox;
};typedef struct lista Lista;
Lista* inicializa(void){
    return NULL;
}
Lista* insereordenado(Lista* l, int i){
    Lista *novo = (Lista*)malloc(sizeof(Lista));
    if(l == NULL){
        novo->info = i;
        novo->prox = NULL;
        return novo;
    }
    else{
        if (i <= l->info){
            novo->info = i;
            novo->prox = l;
            return novo;
        }
        else{
            Lista* p;
            Lista* anterior;
            for (p = l;p != NULL;p = p->prox){
                if((p->prox == NULL)&&(p->info < i)){
                    novo->info = i;
                    novo->prox = NULL;
                    p->prox = novo;
                    return l;
                }
                if((p->prox == NULL)&&(p->info > i)){
                    novo->info = i;
                    novo->prox = p;
                    anterior->prox = novo;
                    return l;
                }
                else if((i >= anterior->info)&&(i <= p->info)){
                    anterior->prox = novo;
                    novo->info = i;
                    novo->prox = p;
                    return l;
                }
                anterior = p;
            }
        }
    }
}
void imprime (Lista* l){
Lista*p;
for (p = l; p != NULL; p = p->prox){
    printf("info = %d\n", p->info);
    }
}

int main(){
    Lista *lista = inicializa();
    printf("Quantos numeros voce deseja inserir\n");
    int n,k,j;
    scanf("%d",&k);
    for(j = 0; j < k; j++){
        scanf("%d",&n);
        lista = insereordenado(lista, n);
    }
    imprime(lista);
    return 0;
}
