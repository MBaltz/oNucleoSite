#include <stdio.h>
#include <stdlib.h>
void inverte(int *v,int tamanho){
    int j ,i ;
    int vetor[tamanho];
    for(j = 0,i=tamanho-1; j <= tamanho; j++,i--){
        vetor[j] = v[i];
    }
    int k;
    for(k = 0;k < tamanho; k++){
        printf("%d ", vetor[k]);
    }
    printf("\n");

}
int main()
{
    int inicial, i;
    printf("Digite a quantidade de numeros a ser inseridos:\n");
    scanf("%d", &inicial);
    int *vetor;
    vetor = malloc(inicial * sizeof(int));
    for(i = 0; i < inicial; i++){
        scanf("%d", &vetor[i]);
    }
    inverte(vetor, inicial);
    free(vetor);
    return 0;
}
