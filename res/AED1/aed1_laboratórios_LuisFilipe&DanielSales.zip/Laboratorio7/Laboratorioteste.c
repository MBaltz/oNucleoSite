#include <stdio.h>
#include <stdlib.h>
int conta_vogais(char *s){
    int i;
    int n = 0;
    for(i = 0; s[i] != '\0'; i++){
        if((s[i] == 'a')||(s[i] == 'A')||(s[i] == 'e')||(s[i] == 'E')||(s[i] == 'i')||(s[i] == 'I')||(s[i] == 'o')||(s[i] == 'O')||(s[i] == 'u')||(s[i] == 'U')){
            n++;
        }
    }
    return n;
}
int main()
{
    char tentativa[100];
    scanf("%s", &tentativa);

    printf("%d", conta_vogais(tentativa));
    return 0;
}
