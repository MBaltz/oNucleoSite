
class Servico:
    def __init__(self, data, peca, tipo_operacao, veiculo=None):
        self.data = data
        self.peca = peca
        self.tipo_operacao = tipo_operacao
        self.veiculo = veiculo
