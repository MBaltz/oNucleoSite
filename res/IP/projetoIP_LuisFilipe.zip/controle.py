from peca import *
from veiculo import *
from servico import *
from problema import *
from funcionario import *
from datetime import date
#Teste
class Controle:

    def __init__(self):
        self.lista_servico = []
        self.lista_peca = []
        self.lista_veiculo = []
        self.lista_funcionario = []
        self.lista_problema = []
        arquivo = open("lista_peca.txt","r")
        for linha in arquivo:
            try:
                atributo = linha.split(";")
                tipo = str(atributo[0])
                modelo = str(atributo[1])
                compra = float(atributo[2])
                venda = float(atributo[3])
                reparo = float(atributo[4])
                peca = Peca(tipo,modelo,compra,venda,reparo)
                self.lista_peca.append(peca)
            except:
                self.lista_peca = self.lista_peca
        arquivo.close()
        
        arquivo = open("lista_problema.txt","r")
        for linha in arquivo:
            try:
                atributo = linha.split(";")
                codigo = int(atributo[0])
                tipo_peca = str(atributo[1])
                modelo_peca = str(atributo[2])
                descricao = str(atributo[3])
                for k in range(len(self.lista_peca)):
                    if self.lista_peca[k].tipo == tipo_peca and self.lista_peca[k].modelo_carro == modelo_peca:
                        peca = self.lista_peca[k]
                        
                problema = Problema(codigo,peca,descricao)
                self.lista_problema.append(problema)
            except:
                self.lista_problema = self.lista_problema
        arquivo.close()
        
        arquivo = open("lista_veiculo.txt","r")
        for linha in arquivo:
            try:
                atributo = linha.split(";")
                proprietario = str(atributo[0])
                placa = str(atributo[1])
                modelo = str(atributo[2])
                codigo = int(atributo[3])
                for k in range(len(self.lista_problema)):
                    if self.lista_problema[k].codigo == codigo:
                        problema = self.lista_problema[k]
                        
                veiculo = Veiculo(proprietario,placa,modelo,problema)
                self.lista_veiculo.append(veiculo)
            except:
                self.lista_veiculo = self.lista_veiculo
        arquivo.close()
        
        arquivo = open("lista_funcionario.txt","r")
        for linha in arquivo:
            try:
                atributo = linha.split("; ")
                nome = str(atributo[0])
                cpf = str(atributo[1])
                escalao = str(atributo[2])
                criptografada = str(atributo[3])
                senha = ""
                for k in range(len(criptografada)):
                    cod = ord(criptografada[k]) - 3
                    letra = str(unichr(cod))
                    senha += letra
                funcionario = Funcionario(nome,cpf,escalao,senha)
                self.lista_funcionario.append(funcionario)
            except:
                self.lista_funcionario = self.lista_funcionario
        arquivo.close()
        
        arquivo = open("lista_servico.txt","r")
        for linha in arquivo:
            try:
                atributo = linha.split(";")
                dia = int(atributo[0])
                mes = int(atributo[1])
                ano = int(atributo[2])
                data = date(ano,mes,dia)
                tipo_peca = str(atributo[3])
                modelo_peca = str(atributo[4])
                for k in range(len(self.lista_peca)):
                    if self.lista_peca[k].tipo == tipo_peca and self.lista_peca[k].modelo_carro == modelo_peca:
                        peca = self.lista_peca[k]
                operacao = str(atributo[5])
                if operacao == "Compra":
                    veiculo = None

                else:
                    placa = str(atributo[6])
                    codigo = int(atributo[7])
                    for j in self.lista_veiculo:
                        if j.placa == placa and j.problema.codigo == codigo:
                            veiculo = j
                            
                servico = Servico(data,peca,operacao,veiculo)
                self.lista_servico.append(servico)
            except:
                self.lista_servico = self.lista_servico
        arquivo.close()

    def registrar_peca(self,tipo,modelo,compra,venda,reparo):
        peca = Peca(tipo,modelo,compra,venda,reparo)
        for k in self.lista_peca:
            if k.tipo == peca.tipo and k.modelo_carro == peca.modelo_carro:
                raise NameError
        self.lista_peca.append(peca)

    def registrar_veiculo(self,proprietario,placa,modelo,problema=None):
        veiculo = Veiculo(proprietario,placa,modelo,problema)
        for k in self.lista_veiculo:
            if k == veiculo or k.placa == veiculo.placa:
                raise NameError
        self.lista_veiculo.append(veiculo)

    def registrar_servico(self,dia,mes,ano,peca,operacao,veiculo=None):
        data = date(ano,mes,dia)
        servico = Servico(data,peca,operacao,veiculo)
        if servico.tipo_operacao != "Compra":
            self.peca_disponivel(peca)
            if servico.veiculo.modelo != servico.peca.modelo_carro:
                raise NameError
        
        self.lista_servico.append(servico)

    def registrar_problema(self,codigo,peca,descricao=""):
        problema = Problema(codigo,peca,descricao)
        for k in self.lista_problema:
            if k.codigo == problema.codigo:
                raise NameError
            
            if k.peca == problema.peca and k.descricao == problema.descricao:
                raise NameError
        self.lista_problema.append(problema)

    def registrar_funcionario(self,nome,cpf,escalao,senha):
        funcionario = Funcionario(nome,cpf,escalao,senha)
        for k in self.lista_funcionario:
            if k == funcionario or k.cpf == funcionario.cpf:
                raise NameError
        self.lista_funcionario.append(funcionario)

    def excluir_funcionario(self,cpf):
        flag = False
        for k in range(len(self.lista_funcionario)):
            if self.lista_funcionario[k].cpf == cpf:
                posicao = k
                flag = True
        self.lista_funcionario.remove(self.lista_funcionario[posicao])
        if flag == False:
            raise NameError
                

    def pecas_utilizadas(self):
        lista_utilizadas = []
        lista_pecas = self.lista_peca
        for peca in self.lista_peca:
            contador = 0
            for k in range(len(self.lista_servico)):
                if self.lista_servico[k].tipo_operacao == "Venda" and self.lista_servico[k].peca == peca:
                    contador += 1

            lista_utilizadas.append(contador)
        nova_lista = []
        while len(lista_utilizadas) > 0:
            maior = lista_utilizadas[0]
            posicao = 0
            for j in range(len(lista_utilizadas)):
                if lista_utilizadas[j] > maior:
                    maior = lista_utilizadas[j]
                    posicao = j
            
            peca_str ="Utilizacoes: "+str(lista_utilizadas[posicao])+" Peca: "+lista_pecas[posicao].tipo +" "+ lista_pecas[posicao].modelo_carro
            nova_lista.append(peca_str)
            lista_utilizadas.remove(lista_utilizadas[posicao])
            lista_pecas.remove(lista_pecas[posicao])

        return nova_lista

    def problemas_recorrentes(self):
        ocorrencia = []
        lista_problemas = self.lista_problema
        for problema in self.lista_problema:
            contador = 0
            for j in range(len(self.lista_servico)):
                if self.lista_servico[j].tipo_operacao != "Compra":
                    if problema == self.lista_servico[j].veiculo.problema:
                        contador += 1

            ocorrencia.append(contador)
        
        lista_2 = []
        while len(ocorrencia) > 0:
            maior_problema = ocorrencia[0]
            posicao = 0
            for i in range(len(ocorrencia)):
                if ocorrencia[i] >= maior_problema:
                    maior_problema = ocorrencia[i]
                    posicao = i
                    
            lista_2.append(lista_problemas[posicao])
            ocorrencia.remove(ocorrencia[posicao])
            lista_problemas.remove(lista_problemas[posicao])
        
        return lista_2

    def lucro_mensal(self,mes,ano):
        lucro = 0
        for k in self.lista_servico:
            if k.data.year == ano and k.data.month == mes:
                if k.tipo_operacao == "Compra":
                    lucro -= k.peca.preco_compra

                elif k.tipo_operacao == "Venda":
                    lucro += k.peca.preco_venda

                else:
                    lucro += k.peca.preco_reparo

        return lucro

    def lucro_anual(self,ano):
        lucro_ano = 0
        for k in self.lista_servico:
            if k.data.year == ano:
                if k.tipo_operacao == "Compra":
                    lucro_ano -= k.peca.preco_compra

                elif k.tipo_operacao == "Venda":
                    lucro_ano += k.peca.preco_venda

                else:
                    lucro_ano += k.peca.preco_reparo
        return lucro_ano

    def login(self,cpf,senha):
        
        for k in range(len(self.lista_funcionario)):
            if cpf == self.lista_funcionario[k].cpf and senha == self.lista_funcionario[k].senha:
                return self.lista_funcionario[k].escalao

        raise NameError

    #So logado
    def mudar_senha(self,cpf,senha,senha_velha):
        flag = False
        for k in range(len(self.lista_funcionario)):
            if cpf == self.lista_funcionario[k].cpf and senha_velha == self.lista_funcionario[k].senha:
                self.lista_funcionario[k].senha = senha
                flag = True
        if flag == False:
            raise NameError

    def promocao(self,cpf):
        flag = False
        for k in range(len(self.lista_funcionario)):
            if cpf == self.lista_funcionario[k].cpf:
                self.lista_funcionario[k].escalao = "Gerente"
                flag = True
        if flag == False:
            raise NameError

    def despromocao(self,cpf):
        flag = False
        for k in range(len(self.lista_funcionario)):
            if cpf == self.lista_funcionario[k].cpf:
                self.lista_funcionario[k].escalao = "Normal"
                flag = True

        if flag == False:
            raise NameError

    def visualizar_funcionario(self):
        return self.lista_funcionario

    def salvar_peca(self):
        arquivo = open("lista_peca.txt","w")
        for k in range(len(self.lista_peca)):
            arquivo.write(str(self.lista_peca[k].tipo)+";")
            arquivo.write(str(self.lista_peca[k].modelo_carro)+";")
            arquivo.write(str(self.lista_peca[k].preco_compra)+";")
            arquivo.write(str(self.lista_peca[k].preco_venda)+";")
            arquivo.write(str(self.lista_peca[k].preco_reparo)+";"+"\n")
        arquivo.close()

    def salvar_funcionario(self):
        arquivo = open("lista_funcionario.txt","w")
        for k in range(len(self.lista_funcionario)):
            arquivo.write(str(self.lista_funcionario[k].nome)+"; ")
            arquivo.write(str(self.lista_funcionario[k].cpf)+"; ")
            arquivo.write(str(self.lista_funcionario[k].escalao)+"; ")
            senha_inicial = str(self.lista_funcionario[k].senha)
            senha = ""
            for j in range(len(senha_inicial)):
                cod = ord(senha_inicial[j]) + 3
                letra = str(unichr(cod))
                senha += letra
            arquivo.write(str(senha)+"; "+"\n")
        arquivo.close()
            
    def salvar_problema(self):
        arquivo = open("lista_problema.txt","w")
        for k in range(len(self.lista_problema)):
            arquivo.write(str(self.lista_problema[k].codigo)+";")
            arquivo.write(str(self.lista_problema[k].peca.tipo)+";")
            arquivo.write(str(self.lista_problema[k].peca.modelo_carro)+";")
            arquivo.write(str(self.lista_problema[k].descricao)+";"+"\n")

        arquivo.close()
        
    def salvar_veiculo(self):
        arquivo = open("lista_veiculo.txt","w")
        for k in range(len(self.lista_veiculo)):
            arquivo.write(str(self.lista_veiculo[k].proprietario)+";")
            arquivo.write(str(self.lista_veiculo[k].placa)+";")
            arquivo.write(str(self.lista_veiculo[k].modelo)+";")
            arquivo.write(str(self.lista_veiculo[k].problema.codigo)+";"+"\n")

        arquivo.close()

    def salvar_servico(self):
        arquivo = open("lista_servico.txt","w")
        for k in range(len(self.lista_servico)):
            arquivo.write(str(self.lista_servico[k].data.day)+";")
            arquivo.write(str(self.lista_servico[k].data.month)+";")
            arquivo.write(str(self.lista_servico[k].data.year)+";")
            arquivo.write(str(self.lista_servico[k].peca.tipo)+";")
            arquivo.write(str(self.lista_servico[k].peca.modelo_carro)+";")
            arquivo.write(str(self.lista_servico[k].tipo_operacao)+";")
            if str(self.lista_servico[k].tipo_operacao) == "Compra":
                arquivo.write("\n")
            else:
                arquivo.write(str(self.lista_servico[k].veiculo.placa)+";")
                arquivo.write(str(self.lista_servico[k].veiculo.problema.codigo)+";"+"\n")
            
    def peca_disponivel(self,peca):
        pecas = 0
        for k in range(len(self.lista_servico)):
            if self.lista_servico[k].peca == peca:
                if self.lista_servico[k].tipo_operacao == "Compra":
                    pecas += 1

                elif self.lista_servico[k].tipo_operacao == "Venda":
                    pecas -= 1
            
        if pecas <= 0:
            raise ValueError
            
        
