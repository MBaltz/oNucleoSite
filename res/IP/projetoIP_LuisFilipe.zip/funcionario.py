
class Funcionario:
    def __init__(self,nome,cpf,escalao,senha):
        self.senha = senha
        self.escalao = escalao
        self.cpf = cpf
        self.nome = nome

    def salvar_funcionarios(self,lista):
        arquivo = open("Lista_funcionario.txt","w")
        arquivo.close()
