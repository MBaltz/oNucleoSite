from login_view import *

root = Tk()
janela = Tela_login(root)
root.mainloop()
