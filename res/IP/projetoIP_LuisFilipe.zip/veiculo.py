class Veiculo:
    def __init__(self, proprietario, placa, modelo, problema=None):
        self.proprietario = proprietario
        self.placa = placa
        self.modelo = modelo
        self.problema = problema
