from Tkinter import *
from controle import *
from tkMessageBox import *
import ttk

class PaginaGerente:
    def __init__(self, master, cpf):
        self.controle = Controle()
        self.master = master
        self.master.title("Fix It")
        self.cpf = cpf
        self.janela_aberta = False
        self.master.geometry("720x480")
        self.master.resizable(width=False, height=False)
        self.nb = ttk.Notebook(self.master,height = "480", width = "720")
        self.page1 = ttk.Frame(self.nb)
        self.imagem = PhotoImage(file = "FIX IT.gif")
        self.label = ttk.Label(self.page1,image=self.imagem)
        self.label.place(x=0, y=0, relwidth=1, relheight=1)
        self.nb.add(self.page1, text="Registros")
        self.nb.pack()
        self.page2 = ttk.Frame(self.nb)
        self.label2 = ttk.Label(self.page2,image=self.imagem)
        self.label2.place(x=0, y=0, relwidth=1, relheight=1)
        self.nb.add(self.page2, text="Listas")
        self.nb.pack()
        self.page3= ttk.Frame(self.nb)
        self.label3 = ttk.Label(self.page3,image=self.imagem)
        self.label3.place(x=0, y=0, relwidth=1, relheight=1)
        self.nb.add(self.page3, text="Exclusoes")
        self.nb.pack()
        self.page4= ttk.Frame(self.nb)
        self.label4 = ttk.Label(self.page4,image=self.imagem)
        self.label4.place(x=0, y=0, relwidth=1, relheight=1)
        self.nb.add(self.page4, text="Atualizacoes")
        self.nb.pack()
        self.labelname = Label(self.page2)
        self.labelname.pack()

        self.button1 = Button(self.page1,width=19,height=3,text="Peca", command=self.NovaPeca)        
        self.button1.pack()
        self.button1.place(x=50,y=50)
        self.button2 = Button(self.page1,width=19,height=3,text="Problema",command=self.NovoProblema)        
        self.button2.pack()
        self.button2.place(x=50,y=200)
        self.button3 = Button(self.page1,width=19,height=3,text="Veiculo c/ Problema", command=self.NovoCarro)
        self.button3.pack()
        self.button3.place(x=500,y=350)
        self.button4 = Button(self.page1,width=19,height=3,text="Novo Funcionario", command=self.NovoFuncionario)        
        self.button4.pack()
        self.button4.place(x=50,y=350)
        self.button5 = Button(self.page1,width=19,height=3,text="Servico(Compra)", command = self.ServicoCompra)
        self.button5.pack()
        self.button5.place(x=500,y=50)
        self.button6 = Button(self.page2,width=19,height=3,text="Lucro Mensal", command=self.ListaLucroMes)
        self.button6.pack()
        self.button6.place(x=400,y=350)
        self.button7 = Button(self.page2,width=19,height=3,text="Lucro Anual", command = self.ListaLucroAno)
        self.button7.pack()
        self.button7.place(x=400,y=250)
        self.button8 = Button(self.page2, width=19,height=3, text="Pecas mais utilizadas", command = self.ListaPecas)
        self.button8.pack()
        self.button8.place(x=150,y=350)
        self.button9 = Button(self.page2, width=19,height=3, text="Problemas Recorrentes", command = self.ListaProblemas)
        self.button9.pack()
        self.button9.place(x=150,y=250)
        self.button10 = Button(self.page4, width=19,height=3,text ="Mudar Senha", command = self.NovoLogin)
        self.button10.pack()
        self.button10.place(x=300,y=250)
        self.button11 = Button(self.page4, width=19,height=3, text="Promover Funcionario", command = self.PromoverFunc)
        self.button11.pack()
        self.button11.place(x=150,y=170)
        self.button12 = Button(self.page4, width=19,height=3, text="Despromover Funcionario", command = self.DespromoverFunc)
        self.button12.pack()
        self.button12.place(x=440,y=170)
        self.button13 = Button(self.page3, width=19,height=3, text="Demitir Funcionario", command = self.DemitirFuncionario)
        self.button13.pack()
        self.button13.place(x=300,y=200)
        self.button14 = Button(self.page1,width=19,height=3,text="Servico(Venda ou Reparo)", command = self.ServicoVenda)
        self.button14.pack()
        self.button14.place(x=500,y=200)
        self.button15 = Button(self.page2, width=19,height=3,text="Lista Funcionarios", command = self.ListaFuncionarios)
        self.button15.place(x=275,y=150)
    def NovaPeca(self):
        if self.janela_aberta == False:
            #self.janela_aberta = True
            a = RegistroPeca()
    def NovoProblema(self):
        if self.janela_aberta == False:
            a = RegistroProblema()
    def NovoCarro(self):
        if self.janela_aberta == False:
            a = RegistroVeiculo()
    def ServicoCompra(self):
        if self.janela_aberta == False:
            a = RegistroServicoCompra()
    def ServicoVenda(self):
        if self.janela_aberta == False:
            a = RegistroServicoVenda()
    def NovoFuncionario(self):
        if self.janela_aberta == False:
            a = RegistroFuncionario()
    def ListaLucroMes(self):
        if self.janela_aberta == False:
            a = LucroMensal()
    def ListaLucroAno(self):
        if self.janela_aberta == False:
            a = LucroAnual()
    def ListaPecas(self):
        if self.janela_aberta == False:
            a = PecasUtilizadas()
    def ListaProblemas(self):
        if self.janela_aberta == False:
            a = ProblemasRecorrentes()
    def NovoLogin(self):
        if self.janela_aberta == False:
            a = MudarSenha(self.cpf)
    def PromoverFunc(self):
        if self.janela_aberta == False:
            a = Promover(self.cpf)
    def DespromoverFunc(self):
        if self.janela_aberta == False:
            a = Despromover(self.cpf)
    def DemitirFuncionario(self):
        if self.janela_aberta == False:
            a = Demitir(self.cpf)
    def ListaFuncionarios(self):
        if self.janela_aberta == False:
            a = ListaFunc()

    
class RegistroPeca:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Tipo')
        self.label_2 = Label(self.root, text='Modelo')
        self.label_3 = Label(self.root, text='Preco de Compra')
        self.label_4 = Label(self.root, text='Preco de Venda')
        self.label_5 = Label(self.root, text='Preco de Reparo')
        self.entrada_1 = Entry(self.root)
        self.entrada_2 = Entry(self.root)
        self.entrada_3 = Entry(self.root)
        self.entrada_4 = Entry(self.root)
        self.entrada_5 = Entry(self.root)

        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=2, sticky=E)
        self.label_3.grid(row=3, sticky=E)
        self.label_4.grid(row=4, sticky=E)
        self.label_5.grid(row=5, sticky=E)
        self.entrada_1.grid(row=1, column=1)
        self.entrada_2.grid(row=2, column=1)
        self.entrada_3.grid(row=3, column=1)
        self.entrada_4.grid(row=4, column=1)
        self.entrada_5.grid(row=5, column=1)
        self.button2 = Button(self.root, width=19, text="Registrar Peca",command=self.criar_peca)
        self.button2.grid(row=6,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=7,column=1)
        self.root.mainloop()
        
    def criar_peca(self):
        try:
            tipo = str(self.entrada_1.get())
            modelo = str(self.entrada_2.get())
            compra = float(self.entrada_3.get())
            venda = float(self.entrada_4.get())
            reparo = float(self.entrada_5.get())
            if len(tipo) == 0 or len(modelo) == 0:
                showerror("Erro","Dados Invalidos")
            elif compra >= venda:
                showerror("Erro","Preco de compra maior que preco venda")
            elif compra <= reparo:
                showerror("Erro","Preco de compra menor igual ao preco reparo")
            else:
                criar = self.controle.registrar_peca(tipo,modelo,compra,venda,reparo)
                self.controle.salvar_peca()
                self.label6 = Label(self.root, text="Registro Efetuado")
                self.label6.grid(row=8,column=1)
        except:
            showerror("Erro","Dados Invalidos")

    def sair(self):
        self.root.destroy()

class RegistroProblema:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("210x150")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Codigo')
        self.label_2 = Label(self.root, text='Peca')
        self.label_3 = Label(self.root, text='Descricao')
        self.lista_opcoes = []
        for k in self.controle.lista_peca:
            string = str(k.tipo) + ";" + str(k.modelo_carro)
            self.lista_opcoes.append(string)
        self.entrada_1 = Entry(self.root)
        self.variavel = StringVar(self.root)
        self.variavel.set("Pecas")
        self.entrada_2 = OptionMenu(self.root, self.variavel,*self.lista_opcoes)
        self.entrada_3 = Entry(self.root)
        
        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=2, sticky=E)
        self.label_3.grid(row=3, sticky=E)
        
        self.entrada_1.grid(row=1, column=1)
        self.entrada_2.grid(row=2, column=1)
        self.entrada_3.grid(row=3, column=1)
        
        self.button2 = Button(self.root, width=19, text="Registrar Problema",command=self.criar_problema)
        self.button2.grid(row=4,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=5,column=1)
        self.root.mainloop()
    def criar_problema(self): 
        try:
            codigo = int(self.entrada_1.get())
            peca_1 = str(self.variavel.get())
            dado_peca = peca_1.split(";")
            tipo = dado_peca[0]
            modelo = dado_peca[1]
            for k in self.controle.lista_peca:
                if tipo == k.tipo and modelo == k.modelo_carro:
                    peca = k
   
            descricao = str(self.entrada_3.get())

            if len(descricao) == 0:
                showerror("Erro","Dados Invalidos")

            else:
                problema = self.controle.registrar_problema(codigo,peca,descricao)
                self.label6 = Label(self.root, text="Registro Efetuado")
                self.label6.grid(row=6,column=1)
                self.controle.salvar_problema()
            
                
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()
class RegistroVeiculo:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Nome')
        self.label_2 = Label(self.root, text='Placa')
        self.label_4 = Label(self.root, text='Problema')
        self.lista_prob = []
        for k in self.controle.lista_problema:
            string = str(k.codigo) + ";" + str(k.peca.modelo_carro)+ ";" + str(k.descricao)
            self.lista_prob.append(string)
        self.entrada_1 = Entry(self.root)
        self.entrada_2 = Entry(self.root)
        self.variavel = StringVar(self.root)
        self.variavel.set("Problemas")
        self.entrada_4 = OptionMenu(self.root, self.variavel,*self.lista_prob)
        

        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=2, sticky=E)
        self.label_4.grid(row=3, sticky=E)
       
        self.entrada_1.grid(row=1, column=1)
        self.entrada_2.grid(row=2, column=1)
        self.entrada_4.grid(row=3, column=1)
      
        self.button2 = Button(self.root, width=19, text="Registrar Veiculo",command=self.criar_veiculo)
        self.button2.grid(row=4,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=5,column=1)
        self.root.mainloop()
    def criar_veiculo(self):
        try:
            problema_1 = str(self.variavel.get())
            atributos = problema_1.split(";")
            codigo = int(atributos[0])
            modelo = str(atributos[1])
            for k in self.controle.lista_problema:
                if codigo == k.codigo:
                    problema = k
            proprietario = str(self.entrada_1.get())
            placa = str(self.entrada_2.get())
            if len(proprietario) == 0 or len(placa) == 0 or len(modelo) == 0:
                showerror("Erro","Dados Invalidos")
            elif len(placa) != 8:
                showerror("Erro","Digite a placa no sistema xxx-1111")
            else:
                veiculo = self.controle.registrar_veiculo(proprietario,placa,modelo,problema)
                self.controle.salvar_veiculo()
                self.label6 = Label(self.root, text="Registro Efetuado")
                self.label6.grid(row=7,column=1)
        except:
            showerror("Erro","Dados Invalidos")
        
    def sair(self):
        self.controle.salvar_veiculo()
        self.root.destroy()
class RegistroServicoCompra:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("430x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Data')
        self.label_2 = Label(self.root, text='Peca')
        self.label_4 = Label(self.root, text='/')
        self.label_5 = Label(self.root, text='/')

        self.lista_ps = []
        for k in self.controle.lista_peca:
            string = str(k.tipo) + ";" + str(k.modelo_carro)
            self.lista_ps.append(string)
        self.variavel = StringVar(self.root)
        self.variavel.set("Pecas")
        self.entrada_4 = OptionMenu(self.root, self.variavel,*self.lista_ps)
        self.entrada_1 = Entry(self.root)
        self.entrada_2 = Entry(self.root)
        self.entrada_3 = Entry(self.root)

        self.label_1.grid(row=1, sticky=E)
        self.entrada_1.grid(row=1, column=1)
        self.label_2.grid(row=2, sticky=E)
        self.label_4.grid(row=1,column=2, sticky=E)
        self.entrada_2.grid(row=1, column=3)
        self.label_5.grid(row=1,column=4, sticky=E)
        self.entrada_3.grid(row=1, column=5)
        self.entrada_4.grid(row=2, column=1)
        self.button2 = Button(self.root, width=19, text="Registrar Servico",command=self.criar_servico_compra)
        self.button2.grid(row=3,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=4,column=1)
        self.root.mainloop()
    def criar_servico_compra(self):
        try:
            dia = int(self.entrada_1.get())
            mes = int(self.entrada_2.get())
            ano = int(self.entrada_3.get())
            peca_1 = str(self.variavel.get())
            dado_peca = peca_1.split(";")
            tipo = dado_peca[0]
            modelo = dado_peca[1]
            for k in self.controle.lista_peca:
                    if tipo == k.tipo and modelo == k.modelo_carro:
                        peca = k                            
            servico = self.controle.registrar_servico(dia,mes,ano,peca,"Compra")
            self.controle.salvar_servico()
            self.label6 = Label(self.root, text="Registro Efetuado")
            self.label6.grid(row=7,column=1)
        except ValueError:
            showerror("Erro","Peca indispon�vel! Compre mais")
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()

class RegistroServicoVenda:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("430x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Data')
        self.label_2 = Label(self.root, text='Peca')
        self.label_4 = Label(self.root, text='Veiculo')
        self.label_3 = Label(self.root, text='Operacao')
        self.label_5 = Label(self.root, text='/')
        self.label_6 = Label(self.root, text='/')
        self.lista_ps = []
        for k in self.controle.lista_peca:
            string = str(k.tipo) + ";" + str(k.modelo_carro)
            self.lista_ps.append(string)
        self.variavel = StringVar(self.root)
        self.lista_cs = []
        for k in self.controle.lista_veiculo:
            string = str(k.placa)
            self.lista_cs.append(string)
        self.variavel_3 = StringVar(self.root)
        self.variavel_3.set("Placas")
        self.variavel = StringVar(self.root)
        self.variavel.set("Pecas")
        self.entrada_4 = OptionMenu(self.root, self.variavel,*self.lista_ps)
        self.entrada_6 = OptionMenu(self.root, self.variavel_3, *self.lista_cs)
        self.variavel_2 = StringVar(self.root)
        self.variavel_2.set("Operacao")
        self.entrada_5 = OptionMenu(self.root, self.variavel_2,"Venda", "Reparo")
        self.entrada_1 = Entry(self.root)
        self.entrada_2 = Entry(self.root)
        self.entrada_3 = Entry(self.root)

        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=2, sticky=E)
        self.label_3.grid(row=3, sticky=E)
        self.label_4.grid(row=4, sticky=E)
        self.label_5.grid(row=1,column=2, sticky=E)
        self.label_6.grid(row=1,column=4, sticky=E)
        self.entrada_1.grid(row=1, column=1)
        self.entrada_2.grid(row=1, column=3)
        self.entrada_3.grid(row=1, column=5)
        self.entrada_4.grid(row=2, column=1)
        self.entrada_5.grid(row=3, column=1)
        self.entrada_6.grid(row=4, column=1)
        self.button2 = Button(self.root, width=19, text="Registrar Servico",command=self.criar_servico_venda)
        self.button2.grid(row=5,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=6,column=1)
        self.root.mainloop()
    def criar_servico_venda(self):
        dia = int(self.entrada_1.get())
        mes = int(self.entrada_2.get())
        ano = int(self.entrada_3.get())
        escolha = str(self.variavel_2.get())
        peca_1 = str(self.variavel.get())
        dado_peca = peca_1.split(";")
        tipo = dado_peca[0]
        modelo = dado_peca[1]
        for k in self.controle.lista_peca:
            if tipo == k.tipo and modelo == k.modelo_carro:
                peca = k
        placa = self.variavel_3.get()
        for i in self.controle.lista_veiculo:
            if placa == i.placa:
                veiculo = i
        servico = self.controle.registrar_servico(dia,mes,ano,peca,escolha, veiculo)
        self.controle.salvar_servico()
        self.label6 = Label(self.root, text="Registro Efetuado")
        self.label6.grid(row=7,column=1)
    def sair(self):
        self.root.destroy()

        
class RegistroFuncionario:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Nome')
        self.label_2 = Label(self.root, text='Cpf')
        self.label_3 = Label(self.root, text='Escalao')
        self.label_4 = Label(self.root, text='Senha')
        self.variavel = StringVar(self.root)
        self.variavel.set("Escalao")
        self.entrada_3 = OptionMenu(self.root, self.variavel, "Gerente", "Normal")
        
        self.entrada_1 = Entry(self.root)
        self.entrada_2 = Entry(self.root)
        self.entrada_4 = Entry(self.root, show='*')
        
        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=2, sticky=E)
        self.label_3.grid(row=3, sticky=E)
        self.label_4.grid(row=4, sticky=E)
        
        self.entrada_1.grid(row=1, column=1)
        self.entrada_2.grid(row=2, column=1)
        self.entrada_3.grid(row=3, column=1)
        self.entrada_4.grid(row=4, column=1)
        
        self.button2 = Button(self.root, width=19, text="Registrar Funcionario",command=self.criar_funcionario)
        self.button2.grid(row=5,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=6,column=1)
        self.root.mainloop()
    def criar_funcionario(self):
        try:
            nome = str(self.entrada_1.get())
            cpf = str(self.entrada_2.get())
            escalao = str(self.variavel.get())
            senha = str(self.entrada_4.get())            
            if len(nome) == 0 or len(cpf) == 0 or len(senha) == 0:
                showerror("Erro","Dados Invalidos")
            elif len(str(cpf)) != 11:
                showerror("Erro","Cpf invalido.")
            else:
                problema = self.controle.registrar_funcionario(nome,cpf,escalao,senha)
                self.controle.salvar_funcionario()
                self.label6 = Label(self.root, text="Registro Efetuado")
                self.label6.grid(row=7,column=1)
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()

class LucroMensal:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("400x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text="Digite o mes e o ano")
        self.label_2 = Label(self.root, text="/")
        self.entrada_1 = Entry(self.root)
        self.entrada_2 = Entry(self.root)
        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=1, column = 3, sticky=E)
        self.entrada_1.grid(row=1,column=1)
        self.entrada_2.grid(row=1, column=4)
        self.button2 = Button(self.root, width=19, text="Ver o Lucro",command=self.ver_lucromensal)
        self.button2.grid(row=2,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=3,column=1)
    def ver_lucromensal(self):
        try:
            mes = int(self.entrada_1.get())
            ano = int(self.entrada_2.get())
            lucromensal = self.controle.lucro_mensal(mes, ano)
            self.label6 = Label(self.root, text=lucromensal)
            self.label6.grid(row=4,column=1)
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()
class LucroAnual:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("350x150")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text="Digite o ano")
        self.entrada_1 = Entry(self.root)
        self.label_1.grid(row=1, sticky=E)
        self.entrada_1.grid(row=1,column=1)
        self.button2 = Button(self.root, width=19, text="Ver o Lucro",command=self.ver_lucroanual)
        self.button2.grid(row=2,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=3,column=1)
    def ver_lucroanual(self):
        try: 
            ano = int(self.entrada_1.get())
            lucroanual = self.controle.lucro_anual(ano)
            self.label6 = Label(self.root, text=lucroanual)
            self.label6.grid(row=4,column=1)
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()
class PecasUtilizadas:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.button2 = Button(self.root, width=19, text="Ver pecas", command=self.pecas_utl)
        self.button2.grid(row=1,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=2,column=1)
    def pecas_utl(self):
        pecasmais = self.controle.pecas_utilizadas()
        pecastr = ""
        if len(pecasmais) < 10:
            for peca in range(len(pecasmais)):
                pecastr += pecasmais[peca] + "\n"
        else:
            for peca in range(10):
                pecastr += pecasmais[peca] + "\n"            
        self.label6 = Label(self.root, text=pecastr)
        self.label6.grid(row=3,column=1)
    def sair(self):
        self.root.destroy()
class ProblemasRecorrentes:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.button2 = Button(self.root, width=19, text="Ver Problemas", command=self.problemas_rec)
        self.button2.grid(row=1,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=2,column=1)
    def problemas_rec(self):
        problemarec = self.controle.problemas_recorrentes()
        problemastr = ""
        if len(problemarec) < 10:
            for problema in range(len(problemarec)):
                problemastr += "Codigo: " + str(problemarec[problema].codigo) + ";" + "Descricao: " + str(problemarec[problema].descricao) + "\n"
        else:
            for problema in range(10):
                problemastr += "Codigo: " + str(problemarec[problema].codigo) + ";" + "Descricao: " + str(problemarec[problema].descricao) + "\n"
        self.label6 = Label(self.root, text=problemastr)
        self.label6.grid(row=3,column=1)
    def sair(self):
        self.root.destroy()
class MudarSenha:
    def __init__(self,cpf):
        self.cpf = cpf
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_2 = Label(self.root, text='Antiga Senha')
        self.label_3 = Label(self.root, text='Nova Senha')
        
    
        self.entrada_2 = Entry(self.root, show='*')
        self.entrada_3 = Entry(self.root, show='*')
        

        self.label_2.grid(row=1, sticky=E)
        self.label_3.grid(row=2, sticky=E)
       
        self.entrada_2.grid(row=1, column=1)
        self.entrada_3.grid(row=2, column=1)
      
        self.button2 = Button(self.root, width=19, text="Mudar Senha",command=self.Mudar_senha)
        self.button2.grid(row=3,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=4,column=1)
        self.root.mainloop()
    def Mudar_senha(self):
        try:
            antigasenha = str(self.entrada_2.get())
            novasenha = str(self.entrada_3.get())
            novologin = self.controle.mudar_senha(self.cpf, novasenha, antigasenha)
            self.controle.salvar_funcionario()
            self.label6 = Label(self.root, text="Mudanca de Senha concluida")
            self.label6.grid(row=5,column=1)
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()
class Promover:
    def __init__(self, cpf):
        self.cpf = cpf
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Cpf')
    
        self.entrada_1 = Entry(self.root)    

        self.label_1.grid(row=1, sticky=E)
       
        self.entrada_1.grid(row=1, column=1)
      
        self.button2 = Button(self.root, width=19, text="Promover",command=self.promote)
        self.button2.grid(row=5,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=6,column=1)
        self.root.mainloop()
    def promote(self):
        try:
            cpf = str(self.entrada_1.get())
            novologin = self.controle.promocao(cpf)
            self.label6 = Label(self.root, text="Funcionario promovido com sucesso")
            self.controle.salvar_funcionario()
            self.label6.grid(row=7,column=1)
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()
class Despromover:
    def __init__(self, cpf):
        self.cpf = cpf
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Cpf')
    
        self.entrada_1 = Entry(self.root)    

        self.label_1.grid(row=1, sticky=E)
       
        self.entrada_1.grid(row=1, column=1)
      
        self.button2 = Button(self.root, width=19, text="Despromover",command=self.unpromote)
        self.button2.grid(row=5,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=6,column=1)
        self.root.mainloop()
    def unpromote(self):
        try:
            cpf = self.entrada_1.get()
            if self.cpf == cpf:
                showerror("Erro","Voce nao pode se despromover")
            else:
                novologin = self.controle.despromocao(cpf)
                self.label6 = Label(self.root, text="Funcionario Despromovido com sucesso")
                self.controle.salvar_funcionario()
                self.label6.grid(row=7,column=1)
        except:
            showerror("Error","Dado invalido")
    def sair(self):
        self.root.destroy()
class Demitir:
    def __init__(self, cpf):
        self.cpf = cpf
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("300x200")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.label_1 = Label(self.root, text='Cpf')
    
        self.entrada_1 = Entry(self.root)    

        self.label_1.grid(row=1, sticky=E)
       
        self.entrada_1.grid(row=1, column=1)
      
        self.button2 = Button(self.root, width=19, text="Demitir",command=self.Demissao)
        self.button2.grid(row=2,column=1)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=3,column=1)
        self.root.mainloop()
    def Demissao(self):
        try:
            cpf = str(self.entrada_1.get())
            if self.cpf == cpf:
                showerror("Erro", "Voce nao pode se demitir")
            else:
                demitir = self.controle.excluir_funcionario(cpf)
                self.label6 = Label(self.root, text = "Demissao Concluida")
                self.controle.salvar_funcionario()
                self.label6.grid(row=4, column=1)
        except:
            showerror("Erro","Dados Invalidos")
    def sair(self):
        self.root.destroy()
class ListaFunc:
    def __init__(self):
        self.controle = Controle()
        self.root = Tk()
        self.root.title("Fix It")
        self.root.geometry("500x400")
        self.root.resizable(width=False,height=False)
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.button2 = Button(self.root, width=19, text="Ver Funcionarios",command=self.ver_funcionarios)
        self.button2.grid(row=1,column=5)
        self.button1 = Button(self.root, width=19,text="Sair",command=self.sair)
        self.button1.grid(row=2,column=5)
    def ver_funcionarios(self):
        funcionarios = self.controle.visualizar_funcionario()
        funcstr = ""
        for k in funcionarios:
            funcstr += "Nome: " + str(k.nome) + " Cpf: " + str(k.cpf) + " Escalao: " + str(k.escalao) + "\n"
        self.label6 = Label(self.root, text=funcstr)
        self.label6.grid(row=3,column=5)
    def sair(self):
        self.root.destroy()




