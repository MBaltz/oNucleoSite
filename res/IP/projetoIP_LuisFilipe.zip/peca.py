class Peca:

    def __init__(self,tipo,modelo,preco_compra,preco_venda,preco_reparo=0):

        self.tipo = tipo
        self.modelo_carro = modelo
        self.preco_compra = preco_compra
        self.preco_venda = preco_venda
        self.preco_reparo = preco_reparo

    def __str__(self):

        return str(self.tipo)+" "+str(self.modelo_carro)
