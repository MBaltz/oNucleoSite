
class Problema:
    def __init__(self,codigo,peca,descricao=""):
        self.codigo = codigo
        self.descricao = descricao
        self.peca = peca

    def __str__(self):

        return "Codigo: "+str(self.codigo)+","+self.peca.tipo+" "+ self.peca.modelo_carro +" "+ self.descricao
