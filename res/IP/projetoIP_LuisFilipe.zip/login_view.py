from Tkinter import *
from tkMessageBox import *
from controle import Controle
from paginagerente import *
from paginanormal import *
class Tela_login:

    def __init__(self,janela):
        self.controle = Controle()
        self.janela = janela
        self.janela.title("Login")
        self.janela.geometry("200x70+500+200")
        self.label_1 = Label(janela, text='CPF')
        self.label_2 = Label(janela, text='Senha')
        self.entrada_1 = Entry(janela)
        self.entrada_2 = Entry(janela, show='*')

        self.label_1.grid(row=1, sticky=E)
        self.label_2.grid(row=2, sticky=E)

        self.entrada_1.grid(row=1, column=1)
        self.entrada_2.grid(row=2, column=1)

        self.botao_logar = Button(janela, text='Login',command = self.autenticar)
        self.botao_logar.grid(columnspan=2)

    def autenticar(self):
        try:
            cpf = self.entrada_1.get()
            senha = self.entrada_2.get()
            autenticacao = self.controle.login(cpf,senha)
            if autenticacao == "Gerente":
                self.janela.destroy()
                janela = Tk()
                pagina = PaginaGerente(janela,cpf)
                janela.mainloop()
                
            elif autenticacao == "Normal":
                self.janela.destroy()
                janela = Tk()
                pagina = PaginaNormal(janela,cpf)
                janela.mainloop()
                
        except:
            showerror('Erro','Usu�rio ou senha inv�lidos')
    

            
root = Tk()
janela = Tela_login(root)
root.mainloop()
