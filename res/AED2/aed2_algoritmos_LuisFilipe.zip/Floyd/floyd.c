#include <stdio.h>
#include <stdlib.h>

typedef struct Grafo{
  int **caminho;
  int **lista;
  int vertices;
  int arestas;
}Grafo;

Grafo* criarGrafo(int vertices){

  Grafo* g = malloc(sizeof(Grafo));
  g->arestas = 0;
  g->vertices = vertices;
  g->lista = (int**)malloc(sizeof(int*)*(vertices+1));
  g->caminho = (int**)malloc(sizeof(int*)*(vertices+1));
  int o,i;
  for (i = 1; i <= vertices; i++) {
    g->lista[i] = malloc(sizeof(int)*(vertices+1));
    for (o = 1; o <= vertices; o++) {
      g->lista[i][o] = 999999999;
    }
  }

  for (i = 1; i <= vertices; i++) {
    g->caminho[i] = malloc(sizeof(int)*(vertices+1));
    for (o = 1; o <= vertices; o++) {
      g->caminho[i][o] = o;
    }
  }
  return g;
}

void addAresta(Grafo* g,int peso,int origem,int destino){
  g->arestas++;
  g->lista[origem][destino] = peso;
}

void imprimir(Grafo* g){
  int k,j;
  for (k = 1; k <= g->vertices; k++){
    for (j = 1; j <= g->vertices; j++) {
      if (j != k){
        printf("(%d-", k);
        printf("%d, ", j);
        printf("%d)", g->lista[k][j]);
    }
    }
    printf("\n");
  }
}

int min(int a, int b){
  if (b <= a){
    return b;
  }
  else{
    return a;
  }
}
void floyd(Grafo* g){

  int k,i,j;
  for (k = 1; k <= g->vertices; k++) {
    for (i = 1; i <= g->vertices; i++) {
      for (j = 1; j <= g->vertices; j++){
        g->lista[i][j] = min(g->lista[i][j],g->lista[i][k]+g->lista[k][j]);
        if (g->lista[i][j] > g->lista[i][k]+g->lista[k][j]){
          g->caminho[i][j] = k;
        }
      }
    }

  }
}

void help(){
  printf("-h                     : mostra o help\n");
  printf("-o <arquivo>           : redireciona a saida para o arquivo\n");
  printf("-f <arquivo>           : indica o arquivo que contém os dados a serem adicionados na AVL\n");
  printf("-i                     : vertice inicial (obrigatorio)\n");
  printf("-l                     : vertice final (opcional)\n");
}

Grafo* montarGrafo(FILE* arquivo){
  int v,a;
  fscanf(arquivo, "%d %d\n",&v,&a);
  Grafo* g = criarGrafo(v);
  char** vetor = (char**)malloc(sizeof(char*)*2);
  int* vetor2 = (int*)malloc(sizeof(int)*2);
  int k;
  for (k = 0; k < 2; k++) {
    vetor[k] = (char*) malloc(sizeof(char));
  }
  fscanf(arquivo,"%d",&vetor2[0]);
  vetor[0][0] = fgetc(arquivo);
  fscanf(arquivo,"%d",&vetor2[1]);
  vetor[1][0] = fgetc(arquivo);
  int origem,destino,peso;

  if (strcmp(vetor[1], " ") == 0){
    fscanf(arquivo, " %d\n", &peso);
    addAresta(g,peso,vetor2[0],vetor2[1]);
    addAresta(g,peso,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d %d\n", &origem,&destino,&peso) != EOF) {
      addAresta(g,peso,origem,destino);
      addAresta(g,peso,destino,origem);
    }
  }
  else{
    addAresta(g,1,vetor2[0],vetor2[1]);
    addAresta(g,1,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d\n", &origem,&destino) != EOF) {
      addAresta(g,1,origem,destino);
      addAresta(g,1,destino,origem);
    }
  }
  return g;
}

void listarCusto(Grafo* g,int v){
  int i;
  for (i = 1; i <= g->vertices; i++) {
    if (v == i){
      printf("%d:%d ", i,0);
    }
    else{
      printf("%d:%d ", i,g->lista[v][i]);
    }
  }
  printf("\n");
}

int main(int argc, char const *argv[]) {
  if (argc == 2){
    help();
    return 1;
  }
  char* endereco = argv[2];
  FILE* arquivo = fopen(endereco, "r");
  if(arquivo == NULL){
      printf("\n \n   ERRO: Arquivo de entrada com problema! \n");
      help();
      return 1;
  }
  Grafo* grafo = montarGrafo(arquivo);

  if (argc == 5 && strcmp(argv[3],"-i")==0){
    floyd(grafo);
    listarCusto(grafo,atoi(argv[4]));
    free(grafo);
    fclose(arquivo);
    return 1;
  }

  if (argc == 7 && strcmp(argv[3],"-i")==0){
    floyd(grafo);
    printf("%d\n", grafo->lista[atoi(argv[4])][atoi(argv[6])]);
    free(grafo);
    fclose(arquivo);
    return 1;
  }
  char* c = argv[4];
  FILE* saida = freopen(c, "w", stdout);
  if(saida == NULL){
      printf("\n \n   ERRO: Arquivo de saida com erro! \n");
      help();
      return 1;
  }
  if (argc == 7 && strcmp(argv[5],"-i")==0){
    floyd(grafo);
    listarCusto(grafo,atoi(argv[6]));
    free(grafo);
    fclose(arquivo);
    return 1;
  }

  if (argc == 9 && strcmp(argv[5],"-i")==0){
    floyd(grafo);
    printf("%d\n", grafo->lista[atoi(argv[6])][atoi(argv[8])]);
    free(grafo);
    fclose(arquivo);
    fclose(saida);
    return 1;
  }
  return 0;
}
