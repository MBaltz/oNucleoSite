#include <stdio.h>
#include <stdlib.h>
typedef struct Aresta{
  int peso;
  int origem;
  int destino;
  struct Aresta *prox;

}Aresta;

typedef struct vertice{
  int num;
  Aresta *adjacentes;
}Vertice;

typedef struct Grafo{
  Vertice* *lista;
  int vertices;
  int arestas;
  int *p;
  int *ordem;
  Aresta* *solucao;
  int elementos;
  Aresta* *prioridade;

}Grafo;


Grafo* iniciarGrafo(int vertices,int arestas){
  Grafo *g;
  g = malloc(sizeof(Grafo));
  g->elementos = 0;
  g->vertices = vertices;
  g->arestas = 0;
  g->p = malloc(sizeof(int)*(vertices+1));
  g->ordem = malloc(sizeof(int)*(vertices+1));
  int y;
  for (y = 1; y <= vertices; y++) {
    g->p[y] = y;
    g->ordem[y] = 0;
  }
  g->lista = malloc((vertices+1)*sizeof(Vertice));
  g->solucao = malloc(sizeof(Aresta*)*(vertices+1));
  g->prioridade = malloc(sizeof(Aresta*)*(arestas+1));
  int k;
  for (k = 1; k <= vertices; k++) {
    Vertice *v = malloc(sizeof(Vertice));
    v->num = k;
    v->adjacentes = NULL;
    g->lista[k] = v;
  }
  return g;
}

void addAresta(Grafo *g,int peso,int origem,int destino){
  Aresta *aresta = malloc(sizeof(Aresta));
  aresta->origem = origem;
  aresta->peso = peso;
  aresta->destino = destino;
  aresta->prox = NULL;
  g->arestas++;

  Aresta *p = g->lista[origem]->adjacentes;
  g->prioridade[g->arestas] = aresta;

  if (p == NULL){
    g->lista[origem]->adjacentes = aresta;
  }
  else{
    while (p->prox != NULL) {
      p = p->prox;
    }
    p->prox = aresta;
  }
}

void addSolucao(Grafo* g, Aresta* a){
  g->elementos++;
  g->solucao[g->elementos] = a;
}

int find(Grafo* g,int x){
  if (x != g->p[x]){
    g->p[x] = find(g,g->p[x]);
  }
  return g->p[x];
}

void link(Grafo* g,int x, int y){
  if (g->ordem[x] > g->ordem[y]) {
    g->p[y] = x;
  }
  else{
    g->p[x] = y;
    if (g->ordem[x] == g->ordem[y]) {
      g->ordem[y]++;
    }
  }
}

void unir(Grafo* g, int x,int y) {
  link(g,find(g,x),find(g,y));
}

void ordenarGrafo(Grafo* g){
  int j;
  Aresta* k;
  int i;
  for(i = 2; i <= g->arestas; i++){
      k = g->prioridade[i];
      for(j = i-1;(j >= 1) && (k->peso < g->prioridade[j]->peso); j--){
          g->prioridade[j + 1] = g->prioridade[j];
      }
      g->prioridade[j+1] = k;
  }
}
void kruskal(Grafo* g){
  ordenarGrafo(g);
  int k;
  for (k = 1; k <= g->arestas; k = k+2) {
    if (g->p[g->prioridade[k]->origem] != g->p[g->prioridade[k]->destino]){
      addSolucao(g,g->prioridade[k]);
      unir(g,g->prioridade[k]->origem,g->prioridade[k]->destino);
    }
  }

}

int custo(Grafo* g){
  int k,c;
  c = 0;
  for (k = 1; k <= g->elementos; k++){
    c = c + g->solucao[k]->peso;
  }
  return c;
}

void caminho(Grafo* g){
  int i,v,aux;
  v = 1;
  for (i = 1; i <= g->elementos; i++) {
    if (g->solucao[i]->origem > g->solucao[i]->destino){
      aux = g->solucao[i]->origem;
      g->solucao[i]->origem = g->solucao[i]->destino;
      g->solucao[i]->destino = aux;
    }
  }
  //ORDENAR
  int j;
  Aresta* k;
  for(i = 2; i <= g->elementos; i++){
      k = g->solucao[i];
      for(j = i-1;(j >= 1) && ((k->origem < g->solucao[j]->origem) || (k->origem == g->solucao[j]->origem && k->destino < g->solucao[j]->destino)); j--){
          g->solucao[j + 1] = g->solucao[j];
      }
      g->solucao[j+1] = k;
  }

  for (i = 1; i <= g->elementos; i++) {
      printf("(%d,", g->solucao[i]->origem);
      printf("%d) ", g->solucao[i]->destino);
  }
  printf("\n");
}

void help(){
  printf("-h                     : mostra o help\n");
  printf("-o <arquivo>           : redireciona a saida para o arquivo\n");
  printf("-f <arquivo>           : indica o arquivo que contém os dados a serem adicionados na AVL\n");
  printf("-s                     : mostra a solucao (ordem crescente)\n");
}

Grafo* montarGrafo(FILE* arquivo){
  int v,a;
  fscanf(arquivo, "%d %d\n",&v,&a);
  Grafo* g = iniciarGrafo(v,a*2);
  char** vetor = (char**)malloc(sizeof(char*)*2);
  int* vetor2 = (int*)malloc(sizeof(int)*2);
  int k;
  for (k = 0; k < 2; k++) {
    vetor[k] = (char*) malloc(sizeof(char));
  }
  fscanf(arquivo,"%d",&vetor2[0]);
  vetor[0][0] = fgetc(arquivo);
  fscanf(arquivo,"%d",&vetor2[1]);
  vetor[1][0] = fgetc(arquivo);
  int origem,destino,peso;

  if (strcmp(vetor[1], " ") == 0){
    fscanf(arquivo, " %d\n", &peso);
    addAresta(g,peso,vetor2[0],vetor2[1]);
    addAresta(g,peso,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d %d\n", &origem,&destino,&peso) != EOF) {
      addAresta(g,peso,origem,destino);
      addAresta(g,peso,destino,origem);
    }
  }
  else{
    addAresta(g,1,vetor2[0],vetor2[1]);
    addAresta(g,1,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d\n", &origem,&destino) != EOF) {
      addAresta(g,1,origem,destino);
      addAresta(g,1,destino,origem);
    }
  }
  return g;
}

int main(int argc, char const *argv[]) {
  //Grafo* g = iniciarGrafo(6,18);
  if (argc == 2){
    help();
    return 1;
  }
  char* endereco = argv[2];
  FILE* arquivo = fopen(endereco, "r");
  if(arquivo == NULL){
      printf("\n \n   ERRO: Arquivo de entrada com problema! \n");
      help();
      return 1;
  }
  Grafo* grafo = montarGrafo(arquivo);

  if (argc == 3){
    kruskal(grafo);
    printf("%d\n", custo(grafo));
    free(grafo);
    fclose(arquivo);
    return 1;
  }
  if (argc == 4){
    kruskal(grafo);
    caminho(grafo);
    free(grafo);
    fclose(arquivo);
    return 1;
  }
  char* c = argv[4];
  FILE* saida = freopen(c, "w", stdout);
  if(saida == NULL){
      printf("\n \n   ERRO: Arquivo de saida com erro! \n");
      help();
      return 1;
  }
  if (argc == 5){
    kruskal(grafo);
    printf("%d\n", custo(grafo));
    free(grafo);
    fclose(arquivo);
    fclose(saida);
    return 1;
  }
  if (argc == 6){
    kruskal(grafo);
    caminho(grafo);
    free(grafo);
    fclose(arquivo);
    fclose(saida);
    return 1;
  }
  return 0;
}
