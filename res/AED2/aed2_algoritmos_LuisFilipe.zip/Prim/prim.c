#include <stdio.h>
#include <stdlib.h>
typedef struct Aresta{
  int peso;
  int origem;
  int destino;
  struct Aresta *prox;

}Aresta;

typedef struct vertice{
  int num; //Qual e o vertice representado
  Aresta *adjacentes;
}Vertice;

typedef struct Grafo{
  Vertice* *lista;
  int vertices;
  int arestas;
}Grafo;


Grafo* iniciarGrafo(int vertices){
  Grafo *g;
  g = malloc(sizeof(Grafo));
  g->vertices = vertices;
  g->arestas = 0;
  g->lista = malloc((vertices+1)*sizeof(Vertice));
  int k;
  for (k = 1; k <= vertices; k++) {
    Vertice *v = malloc(sizeof(Vertice));
    v->num = k;
    v->adjacentes = NULL;
    g->lista[k] = v;
  }
  return g;
}

void addAresta(Grafo *g,int peso,int origem,int destino){
  Aresta *aresta = malloc(sizeof(Aresta));
  aresta->origem = origem;
  aresta->peso = peso;
  aresta->destino = destino;
  aresta->prox = NULL;
  g->arestas++;

  Aresta *p = g->lista[origem]->adjacentes;

  if (p == NULL){
    g->lista[origem]->adjacentes = aresta;
  }
  else{
    while (p->prox != NULL) {
      p = p->prox;
    }
    p->prox = aresta;
  }
}

typedef struct Heap{
  Aresta* *vet;
  Aresta* *solucao;
  int *visitados;
  int *prev;
  int *custo;
  int tamanho;
  int elementos;
  int arestas;
}Heap;

Heap* criarHeap(int tamanho,int arestas){
  Heap* heap = malloc(sizeof(Heap));
  heap->vet = malloc(sizeof(Aresta*)*(arestas+1));
  heap->solucao = malloc(sizeof(Aresta*)*(tamanho+1));
  heap->tamanho = tamanho;
  heap->elementos = 0;
  heap->arestas = 0;
  heap->prev = malloc(sizeof(int)*(tamanho+1));
  heap->visitados = malloc(sizeof(int)*(tamanho+1));
  heap->custo = malloc(sizeof(int)*(tamanho+1));
  int i;
  for (i = 1; i <= tamanho; i++) {
    heap->visitados[i] = 0;
    heap->custo[i] = 999999999;
    heap->prev[i] = -1;
  }
  return heap;
}

int pai(int i){
  return (i/2);
}
int esquerda(int i){
  return 2*i;
}
int direita(int i){
  return (2*i)+1;
}

void minHeapify(Heap* h, int i){
  int e = esquerda(i);
  int d = direita(i);
  int menor = i;

  if (e <= h->elementos && h->vet[e]->peso < h->vet[i]->peso){
    menor = e;
  }
  if (d <= h->elementos && h->vet[d]->peso < h->vet[menor]->peso){
    menor = d;
  }
  if (menor != i){
    Aresta* aux = h->vet[i];
    h->vet[i] = h->vet[menor];
    h->vet[menor] = aux;
    minHeapify(h,menor);
  }
}

void construirHeapMin(Heap* h){
  for (int i = h->elementos/2; i >= 1; i--){
    minHeapify(h,i);
  }
}

Aresta* extrairMinimo(Heap* h){
  if (h->elementos < 1){
    return NULL;
  }
  Aresta* min = h->vet[1];
  h->vet[1] = h->vet[h->elementos];
  h->elementos -= 1;
  minHeapify(h,1);
  return min;
}

void inserir(Heap* h,Aresta* aresta){
  h->elementos += 1;
  h->vet[h->elementos] = aresta;
  construirHeapMin(h);
}

void imprimir(Grafo* g) {
 int i;

 for (i = 1; i <= g->vertices; i++) {
   printf("%d: ", i);
   Aresta *a;
   for (a = g->lista[i]->adjacentes; a != NULL; a = a->prox) {
     printf("(Para:%d ", a->destino);
     printf("Peso:%d)", a->peso);
   }
   printf("\n");
 }
 return;
}

void addSolucao(Heap* h,Aresta* a){
  h->arestas++;
  h->solucao[h->arestas] = a;
}

Heap* Prim(Grafo* g){
  Heap* h = criarHeap(g->vertices,g->arestas);
  //Vertice inicial 1
  h->custo[1] = 0;
  h->visitados[1] = 1;
  Aresta* p = g->lista[1]->adjacentes;
  while (p != NULL) {
    inserir(h,p);
    p = p->prox;
  }
  int cont = 1;
  while (h->elementos > 0) {
    Aresta* u = extrairMinimo(h);
    if (cont >= g->vertices){
      break;
    }
    if (h->visitados[u->destino] == 0) {
      cont++;
      addSolucao(h,u);
      h->visitados[u->destino] = 1;
      h->custo[u->destino] = u->peso;
      h->prev[u->destino] = u->origem;
      p = g->lista[u->destino]->adjacentes;
      while (p != NULL) {
        inserir(h,p);
        p = p->prox;
      }
    }
  }
  return h;
}

void caminho(Heap* h){
  int i,v,aux;
  /*for (i = 1; i <= h->arestas; i++) {
      printf("(%d,", h->solucao[i]->origem);
      printf("%d) ", h->solucao[i]->destino);
  }*/
  v = 1;
  for (i = 1; i <= h->arestas; i++) {
    if (h->solucao[i]->origem > h->solucao[i]->destino){
      aux = h->solucao[i]->origem;
      h->solucao[i]->origem = h->solucao[i]->destino;
      h->solucao[i]->destino = aux;
    }
  }
  //ORDENAR
  int j;
  Aresta* k;
  for(i = 2; i <= h->arestas; i++){
      k = h->solucao[i];
      for(j = i-1;(j >= 1) && ((k->origem < h->solucao[j]->origem) || (k->origem == h->solucao[j]->origem && k->destino < h->solucao[j]->destino)); j--){
          h->solucao[j + 1] = h->solucao[j];
      }
      h->solucao[j+1] = k;
  }

  for (i = 1; i <= h->arestas; i++) {
      printf("(%d,", h->solucao[i]->origem);
      printf("%d) ", h->solucao[i]->destino);
  }
  printf("\n");
}

int custo(Heap* h){
  int i,custo;
  custo = 0;
  for (i = 1; i <= h->tamanho; i++) {
    custo = custo + h->custo[i];
  }
  return custo;
}

void help(){
  printf("-h                     : mostra o help\n");
  printf("-o <arquivo>           : redireciona a saida para o arquivo\n");
  printf("-f <arquivo>           : indica o arquivo que contém os dados a serem adicionados na AVL\n");
  printf("-s                     : mostra a solucao (ordem crescente)\n");
}

Grafo* montarGrafo(FILE* arquivo){
  int v,a;
  fscanf(arquivo, "%d %d\n",&v,&a);
  Grafo* g = iniciarGrafo(v);
  char** vetor = (char**)malloc(sizeof(char*)*2);
  int* vetor2 = (int*)malloc(sizeof(int)*2);
  int k;
  for (k = 0; k < 2; k++) {
    vetor[k] = (char*) malloc(sizeof(char));
  }
  fscanf(arquivo,"%d",&vetor2[0]);
  vetor[0][0] = fgetc(arquivo);
  fscanf(arquivo,"%d",&vetor2[1]);
  vetor[1][0] = fgetc(arquivo);
  int origem,destino,peso;

  if (strcmp(vetor[1], " ") == 0){
    fscanf(arquivo, " %d\n", &peso);
    addAresta(g,peso,vetor2[0],vetor2[1]);
    addAresta(g,peso,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d %d\n", &origem,&destino,&peso) != EOF) {
      addAresta(g,peso,origem,destino);
      addAresta(g,peso,destino,origem);
    }
  }
  else{
    addAresta(g,1,vetor2[0],vetor2[1]);
    addAresta(g,1,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d\n", &origem,&destino) != EOF) {
      addAresta(g,1,origem,destino);
      addAresta(g,1,destino,origem);
    }
  }
  return g;
}

int main(int argc, char const *argv[]) {
  if (argc == 2){
    help();
    return 1;
  }
  char* endereco = argv[2];
  FILE* arquivo = fopen(endereco, "r");
  if(arquivo == NULL){
      printf("\n \n   ERRO: Arquivo de entrada com problema! \n");
      help();
      return 1;
  }
  Grafo* grafo = montarGrafo(arquivo);

  if (argc == 3){
    Heap* h;
    h = Prim(grafo);
    printf("%d\n", custo(h));
    free(h);
    free(grafo);
    fclose(arquivo);
    return 1;
  }
  if (argc == 4){
    Heap* h;
    h = Prim(grafo);
    caminho(h);
    free(h);
    free(grafo);
    fclose(arquivo);
    return 1;
  }
  char* c = argv[4];
  FILE* saida = freopen(c, "w", stdout);
  if(saida == NULL){
      printf("\n \n   ERRO: Arquivo de saida com erro! \n");
      help();
      return 1;
  }
  if (argc == 5){
    Heap* h;
    h = Prim(grafo);
    printf("%d\n", custo(h));
    free(h);
    free(grafo);
    fclose(arquivo);
    fclose(saida);
    return 1;
  }
  if (argc == 6){
    Heap* h;
    h = Prim(grafo);
    caminho(h);
    free(h);
    free(grafo);
    fclose(arquivo);
    fclose(saida);
    return 1;
  }
  return 0;
}
