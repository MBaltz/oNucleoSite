#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct no{

  int valor;
  struct no* pai;
  struct no* esq;
  struct no* dir;
  int cor; //0 VERMELHO --- 1 PRETO
}No;

typedef struct Arvore{
  No* raiz;
}Arvore;

No* criarNo(int valor){
  No* no = malloc(sizeof(No));
  no->cor = 0;
  no->esq = NULL;
  no->dir = NULL;
  no->pai = NULL;
  no->valor = valor;
  return no;
}

Arvore* iniciarArvore(){
  Arvore *arvore = malloc(sizeof(Arvore));
  return arvore;
}

void percursoEmOrdem(No* x){
  if (x == NULL){
    return;
  }
  percursoEmOrdem(x->esq);
  printf("%d%s\n",x->valor,x->cor);
  percursoEmOrdem(x->dir);
}

void percursoPreOrdem(No* x){
  if (x == NULL){
    return;
  }
  printf("%d\n",x->valor);
  percursoPreOrdem(x->esq);
  percursoPreOrdem(x->dir);
}

void percursoPosOrdem(No* x){
  if (x == NULL){
    return;
  }
  percursoPosOrdem(x->esq);
  percursoPosOrdem(x->dir);
  printf("%d\n",x->valor);
}

No* buscar(No* x,int k){
  if (x == NULL || k==x->valor){
    return x;
  }
  if (k < x->valor){
    return buscar(x->esq,k);
  }
  else{
    return buscar(x->dir,k);
  }
}

No* minimo(No* x){
  if (x == NULL){
    return x;
  }
  while (x->esq != NULL) {
    x = x->esq;
  }
  return x;
}

No* maximo(No* x){
  if (x == NULL){
    return x;
  }
  while (x->dir != NULL) {
    x = x->dir;
  }
  return x;
}

No* sucessor(No* x){
  if (x == NULL){
    return x;
  }
  if (x->dir != NULL){
    return minimo(x->dir);
  }
  No* y = x->pai;
  while (y != NULL && x==y->dir) {
    x = y;
    y = y->pai;
  }
  return y;
}

No* predecessor(No* x){
  if (x == NULL){
    return x;
  }
  if (x->esq != NULL){
    return maximo(x->esq);
  }
  else{
    return NULL;
  }
}

int getAltura(No* p){
  if (p == NULL){
    return 0;
  }
  int e = getAltura(p->esq);
  int d = getAltura(p->dir);
  if (e>d){
    return 1+e;
  }
  else{
    return 1+d;
  }
}

int getAlturaPreta(No* p){
  if (p == NULL){
    return 0;
  }
  int e = getAlturaPreta(p->esq);
  int d = getAlturaPreta(p->dir);
  if (p->cor == 'r'){
    if (e>d){
      return e;
    }
    else{
      return d;
    }
  }
  else{
    if(e>d){
      return 1+e;
    }
    else{
      return 1+d;
    }
  }
}


void rotacaoDireita(Arvore* t,No* p){
  No* u = p->esq;

  p->esq = u->dir;
  if(p->esq != NULL){
    p->esq->pai = p;
  }
  u->pai = p->pai;
  u->dir = p;
  if (t->raiz == p){
    t->raiz = u;
  }else if (p->pai->valor > p->valor){
    p->pai->esq = u;
  }
  else{
    p->pai->dir = u;
  }
    p->pai = u;
}
void rotacaoEsquerda(Arvore* t,No* p){
  No* u = p->dir;
  p->dir = u->esq;
  if(p->dir != NULL){
    p->dir->pai = p;
  }
  u->pai = p->pai;
  u->esq = p;
  if (p == t->raiz){
    t->raiz = u;
  }
  else if(p->valor < p->pai->valor){
    p->pai->esq = u;
  }
  else{
    p->pai->dir = u;
  }
  p->pai = u;
}
void rotacaoDuplaDireita(Arvore* t,No* p){
  No* u = p->esq;
  rotacaoEsquerda(t,u);
  rotacaoDireita(t,p);
}
void rotacaoDuplaEsquerda(Arvore* t,No* p){
  No* u = p->dir;
  rotacaoDireita(t,u);
  rotacaoEsquerda(t,p);
}
//Funcao para corrigir a rubro negra, caso pai seja vermelho e o filho tambem vermelho essa funcao sera utilizada
void correcaoRN(Arvore* t, No* p){
  No* pai = p->pai;
  No* avo = p->pai->pai;
  No* tio;
  char lado;
  if (pai->esq == p){
    lado = 'e';
  }
  else{
    lado = 'd';
  }
  if (p->pai->cor == 0 && p->cor == 0){

    if (avo->esq == pai){

      tio = avo->dir;
      if (tio != NULL && tio->cor == 0){

        pai->cor = 1;
        tio->cor = 1;
        avo->cor = 0;
      }
      else{
        //Tio preto
        if (lado == 'd'){
          //Mesmo lado
          rotacaoEsquerda(t,pai);
        }
        else{
          //Lado Oposto;
          avo->cor = 0;
          pai->cor = 1;
          rotacaoDireita(t,avo);
        }
      }
    }
    else{
      //Tio esquerdo
      tio = avo->esq;
      if (tio != NULL && tio->cor == 0){
        //Tio vermelho
        pai->cor = 1;
        tio->cor = 1;
        avo->cor = 0;
      }
      else{
        //Tio preto
        if (lado == 'e'){
          //mesmo lado
          rotacaoDireita(t,pai);
        }
        else{
          //lado oposto
          avo->cor = 0;
          pai->cor = 1;
          rotacaoEsquerda(t,avo);
        }
      }
    }
  }
  t->raiz->cor = 1;
}
No* inserir(Arvore* t, No* z){
  No* y = NULL;
  No* x = t->raiz;

  while (x != NULL) {
    y = x;
    if (z->valor < x->valor){
      x = x->esq;
    }
    else{
      x = x->dir;
    }
  }
  z->pai = y;
  if (y == NULL){
    t->raiz = z;
  }
  else if(z->valor < y->valor){
    y->esq = z;
  }
  else{
    y->dir = z;
  }
  No* p = z;
  No* prox = p->pai;
  t->raiz->cor = 1;
  if (p->pai != NULL && p->pai != t->raiz){
    while (p->pai != NULL){
      prox = p->pai;
      correcaoRN(t,p);
      p = prox;
    }
  }
}
void help(){
  printf("-o <arquivo>          : redireciona a saida para o arquivo\n");
  printf("-f <arquivo>           : indica o arquivo que contém os dados a serem adicionados na RN\n");
  printf("-m                     : imprime o menor elemento da RN\n");
  printf("-M                     : imprime o maior elemento da RN\n");
  printf("-a <elemento>          : imprime o antecessor na RN do elemento ou caso contrário imprime -1\n");
  printf("-s <elemento>          : imprime o sucessor na RN do elemento ou caso contrário imprime -1\n");
}

Arvore* montarArvore(FILE* arquivo){
  int inicio;
  fscanf(arquivo, "%d", &inicio);
  Arvore* arvore = iniciarArvore();
  No* no = criarNo(inicio);
  inserir(arvore,no);
  int n;
  while(fscanf(arquivo, "%d\n", &n) != EOF){
    no = criarNo(n);
    inserir(arvore,no);

  }
  return arvore;
}

void imprimir(No* raiz){
  if (raiz == NULL){
      printf("X");
      return;
  }
  printf(" (");
  printf("%d", raiz->valor);
  if(raiz->cor == 1){
      printf("N");
  }
  if(raiz->cor == 0){
      printf("R");
  }

  if (raiz->esq != NULL && raiz->dir != NULL){
      imprimir(raiz->esq);
      imprimir(raiz->dir);
  } else if (raiz->esq != NULL){
          imprimir(raiz->esq);
          printf("(X)");
  } else if (raiz->dir != NULL){
          printf("(X)");
          imprimir(raiz->dir);
  }
  printf(")");
}

int main(int argc, char *argv[]){
  if(argc == 1) {
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    return 1;
}

 if(strcmp(argv[1], "-h") == 0 && argc == 2){
    help();
    return 0;
 }

 if(argc > 5){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    return 1;
 }


 if(strcmp(argv[1], "-f") != 0){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    return 1;
 }

char* endereco = argv[2];
FILE* arquivo = fopen(endereco, "r");
if(arquivo == NULL){
    printf("\n \n   ERRO: Arquivo de entrada com problema! \n");
    help();
    return 1;
}
if (argc == 3){
  Arvore* arvore = montarArvore(arquivo);
  imprimir(arvore->raiz);
  fclose(arquivo);
  return 0;

}

if(strcmp(argv[3], "-M") == 0){
    Arvore* arvore = montarArvore(arquivo);
    printf("%d\n", maximo(arvore->raiz)->valor);
    fclose(arquivo);
    return 0;
}

if(strcmp(argv[3], "-m") == 0){
    Arvore* arvore = montarArvore(arquivo);
    printf("%d\n", minimo(arvore->raiz)->valor);
    fclose(arquivo);
    return 0;
}

if(argc < 5){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    fclose(arquivo);
    return 1;
 }


if(strcmp(argv[3], "-a") == 0){
    Arvore* arvore = montarArvore(arquivo);
int num = atoi(argv[4]);
    No* no = buscar(arvore->raiz, num);
    int pr = predecessor(no)->valor;
    if(pr == NULL){
      int o = -1;
      printf("%d\n", o);
      return 0;
    }
    printf("%d\n", pr);
    fclose(arquivo);
    return 0;
}

if(strcmp(argv[3], "-s") == 0){
    Arvore* arvore = montarArvore(arquivo);
    int num = atoi(argv[4]);
    No* no = buscar(arvore->raiz, num);
    int s = sucessor(no)->valor;
    if(s == NULL){
      int o = -1;
      printf("%d\n", o);
      return 0;
    }
    printf("%d\n", s);
    fclose(arquivo);
    return 0;
}


if(strcmp(argv[3], "-o") != 0){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    fclose(arquivo);
    return 1;
}


if(strcmp(argv[3], "-o") == 0){
    char* caminho = argv[4];
    FILE* arquivo_saida = freopen(caminho, "w", stdout);
    if(arquivo_saida == NULL){
        printf("\n \n   ERRO: Arquivo de saida com erro! \n");
        help();
        return 1;
    }
    Arvore* arvore = montarArvore(arquivo);
    fclose(arquivo);
    imprimir(arvore->raiz);
    fclose(arquivo_saida);
    return 0;
}


return 0;

}
