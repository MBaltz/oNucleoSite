#include <stdio.h>
#include <stdlib.h>

typedef struct Aresta{
  int peso;
  int origem;
  int destino;
  struct Aresta *prox;

}Aresta;

typedef struct vertice{
  int num; //Qual e o vertice representado
  Aresta *adjacentes;
  int custo;
}Vertice;

typedef struct Grafo{
  Vertice* *lista;
  int vertices;
  int arestas;
}Grafo;


Grafo* iniciarGrafo(int vertices){
  Grafo *g;
  g = malloc(sizeof(Grafo));
  g->vertices = vertices;
  g->arestas = 0;
  g->lista = malloc((vertices+1)*sizeof(Vertice));
  int k;
  for (k = 1; k <= vertices; k++) {
    Vertice *v = malloc(sizeof(Vertice));
    v->num = k;
    v->adjacentes = NULL;
    v->custo = 999999999;
    g->lista[k] = v;
  }
  return g;
}

void addAresta(Grafo *g,int peso,int origem,int destino){
  Aresta *aresta = malloc(sizeof(Aresta));
  aresta->origem = origem;
  aresta->peso = peso;
  aresta->destino = destino;
  aresta->prox = NULL;
  g->arestas++;

  Aresta *p = g->lista[origem]->adjacentes;

  if (p == NULL){
    g->lista[origem]->adjacentes = aresta;
  }
  else{
    while (p->prox != NULL) {
      p = p->prox;
    }
    p->prox = aresta;
  }
}

typedef struct Heap{
  Vertice* *vet;
  int *visitados;
  int *prev;
  int *custo;
  int tamanho;
  int elementos;
}Heap;

Heap* criarHeap(int tamanho,int arestas,Grafo* g){
  Heap* heap = malloc(sizeof(Heap));
  heap->vet = malloc(sizeof(Vertice*)*(tamanho+1));
  heap->elementos = 0;
  int t;
  for (t = 1; t <= tamanho; t++) {
    inserir(heap,g->lista[t]);
  }
  heap->tamanho = tamanho;
  heap->prev = malloc(sizeof(int)*(tamanho+1));
  heap->visitados = malloc(sizeof(int)*(tamanho+1));
  heap->custo = malloc(sizeof(int)*(tamanho+1));
  int i;
  for (i = 1; i <= tamanho; i++) {
    heap->visitados[i] = 0;
    heap->custo[i] = 999999999;
    heap->prev[i] = -1;
  }
  return heap;
}

int pai(int i){
  return (i/2);
}
int esquerda(int i){
  return 2*i;
}
int direita(int i){
  return (2*i)+1;
}

void minHeapify(Heap* h, int i){
  int e = esquerda(i);
  int d = direita(i);
  int menor = i;

  if (e <= h->elementos && h->vet[e]->custo < h->vet[i]->custo){
    menor = e;
  }
  if (d <= h->elementos && h->vet[d]->custo < h->vet[menor]->custo){
    menor = d;
  }
  if (menor != i){
    Vertice* aux = h->vet[i];
    h->vet[i] = h->vet[menor];
    h->vet[menor] = aux;
    minHeapify(h,menor);
  }
}

void construirHeapMin(Heap* h){
  for (int i = h->elementos/2; i >= 1; i--){
    minHeapify(h,i);
  }
}

Vertice* extrairMinimo(Heap* h){
  if (h->elementos < 1){
    return NULL;
  }
  Vertice* min = h->vet[1];
  h->vet[1] = h->vet[h->elementos];
  h->elementos -= 1;
  minHeapify(h,1);
  return min;
}

void inserir(Heap* h,Vertice* v){
  h->elementos += 1;
  h->vet[h->elementos] = v;
  construirHeapMin(h);
}

void imprimir(Grafo* g) {
 int i;

 for (i = 1; i <= g->vertices; i++) {
   printf("%d: ", i);
   Aresta *a;
   for (a = g->lista[i]->adjacentes; a != NULL; a = a->prox) {
     printf("(Para:%d ", a->destino);
     printf("Peso:%d)", a->peso);
   }
   printf("\n");
 }
 return;
}
int ind(int e, Heap* h){
  int i;
  for (i = 1; i <= h->tamanho; i++) {
    if (e == h->vet[i]->num){
      return i;
    }
  }
  return -1;
}

Heap* Dijkstra(Grafo* g, int partida){
  Heap* h = criarHeap(g->vertices,g->arestas,g);
  h->custo[partida] = 0;
  h->vet[ind(partida,h)]->custo = 0;
  construirHeapMin(h);
  //printf("%d\n", h->vet[1]->num);
  Aresta* p = extrairMinimo(h)->adjacentes;
  int execucao = 1;
  while (execucao < g->vertices) {
    while (p != NULL) {
      if(h->custo[p->destino] > p->peso + h->custo[p->origem]){
        h->custo[p->destino] = p->peso + h->custo[p->origem];
        h->vet[ind(p->destino,h)]->custo = h->custo[p->destino];
        h->prev[p->destino] = p->origem;
      }
      p = p->prox;
    }
    construirHeapMin(h);

    p = extrairMinimo(h)->adjacentes;
    execucao++;
  }
  return h;
}

void listarCusto(Heap* h){
  int i;
  for (i = 1; i <= h->tamanho; i++) {
    printf("%d:%d ", i,h->custo[i]);
  }
  printf("\n");
}

void help(){
  printf("-h                     : mostra o help\n");
  printf("-o <arquivo>           : redireciona a saida para o arquivo\n");
  printf("-f <arquivo>           : indica o arquivo que contém os dados a serem adicionados na AVL\n");
  printf("-i                     : vertice inicial (obrigatorio)\n");
  printf("-l                     : vertice final (opcional)\n");
}

Grafo* montarGrafo(FILE* arquivo){
  int v,a;
  fscanf(arquivo, "%d %d\n",&v,&a);
  Grafo* g = iniciarGrafo(v);
  char** vetor = (char**)malloc(sizeof(char*)*2);
  int* vetor2 = (int*)malloc(sizeof(int)*2);
  int k;
  for (k = 0; k < 2; k++) {
    vetor[k] = (char*) malloc(sizeof(char));
  }
  fscanf(arquivo,"%d",&vetor2[0]);
  vetor[0][0] = fgetc(arquivo);
  fscanf(arquivo,"%d",&vetor2[1]);
  vetor[1][0] = fgetc(arquivo);
  int origem,destino,peso;

  if (strcmp(vetor[1], " ") == 0){
    fscanf(arquivo, " %d\n", &peso);
    addAresta(g,peso,vetor2[0],vetor2[1]);
    addAresta(g,peso,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d %d\n", &origem,&destino,&peso) != EOF) {
      addAresta(g,peso,origem,destino);
      addAresta(g,peso,destino,origem);
    }
  }
  else{
    addAresta(g,1,vetor2[0],vetor2[1]);
    addAresta(g,1,vetor2[1],vetor2[0]);
    free(vetor);
    while (fscanf(arquivo, "%d %d\n", &origem,&destino) != EOF) {
      addAresta(g,1,origem,destino);
      addAresta(g,1,destino,origem);
    }
  }
  return g;
}

int main(int argc, char const *argv[]) {
  if (argc == 2){
    help();
    return 1;
  }
  char* endereco = argv[2];
  FILE* arquivo = fopen(endereco, "r");
  if(arquivo == NULL){
      printf("\n \n   ERRO: Arquivo de entrada com problema! \n");
      help();
      return 1;
  }
  Grafo* grafo = montarGrafo(arquivo);

  if (argc == 5 && strcmp(argv[3],"-i")==0){
    Heap* h;
    h = Dijkstra(grafo,atoi(argv[4]));
    listarCusto(h);
    free(h);
    free(grafo);
    fclose(arquivo);
    return 1;
  }

  if (argc == 7 && strcmp(argv[3],"-i")==0){
    Heap* h;
    h = Dijkstra(grafo,atoi(argv[4]));
    printf("%d\n", h->custo[atoi(argv[6])]);
    free(h);
    free(grafo);
    fclose(arquivo);
    return 1;
  }
  char* c = argv[4];
  FILE* saida = freopen(c, "w", stdout);
  if(saida == NULL){
      printf("\n \n   ERRO: Arquivo de saida com erro! \n");
      help();
      return 1;
  }
  if (argc == 7 && strcmp(argv[5],"-i")==0){
    Heap* h;
    h = Dijkstra(grafo,atoi(argv[6]));
    listarCusto(h);
    free(h);
    free(grafo);
    fclose(arquivo);
    return 1;
  }

  if (argc == 9 && strcmp(argv[5],"-i")==0){
    Heap* h;
    h = Dijkstra(grafo,atoi(argv[6]));
    printf("%d\n", h->custo[atoi(argv[8])]);
    free(h);
    free(grafo);
    fclose(arquivo);
    fclose(saida);
    return 1;
  }
  return 0;
}
