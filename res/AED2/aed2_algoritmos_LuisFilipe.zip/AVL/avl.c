#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct no{

  int valor;
  struct no* pai;
  struct no* esq;
  struct no* dir;
}No;

typedef struct Arvore{

  No* raiz;
}Arvore;

No* criarNo(int valor){
  No* no = malloc(sizeof(No));
  no->esq = NULL;
  no->dir = NULL;
  no->pai = NULL;
  no->valor = valor;
  return no;
}

Arvore* iniciarArvore(){
  Arvore *arvore = malloc(sizeof(Arvore));
  arvore->raiz = NULL;
  return arvore;
}

void percursoEmOrdem(No* x){
  if (x == NULL){
    return;
  }
  percursoEmOrdem(x->esq);
  printf("%d\n",x->valor);
  percursoEmOrdem(x->dir);
}

void percursoPreOrdem(No* x){
  if (x == NULL){
    return;
  }
  printf("%d\n",x->valor);
  percursoPreOrdem(x->esq);
  percursoPreOrdem(x->dir);
}

void percursoPosOrdem(No* x){
  if (x == NULL){
    return;
  }
  percursoPosOrdem(x->esq);
  percursoPosOrdem(x->dir);
  printf("%d\n",x->valor);
}

No* buscar(No* x,int k){
  if (x == NULL || k==x->valor){
    return x;
  }
  if (k < x->valor){
    return buscar(x->esq,k);
  }
  else{
    return buscar(x->dir,k);
  }
}

No* minimo(No* x){
  if (x == NULL){
    return x;
  }
  while (x->esq != NULL) {
    x = x->esq;
  }
  return x;
}

No* maximo(No* x){
  if (x == NULL){
    return x;
  }
  while (x->dir != NULL) {
    x = x->dir;
  }
  return x;
}

No* sucessor(No* x){
  if (x == NULL){
    return x;
  }
  if (x->dir != NULL){
    return minimo(x->dir);
  }
  No* y = x->pai;
  while (y != NULL && x==y->dir) {
    x = y;
    y = y->pai;
  }
  return y;
}

No* predecessor(No* x){
  if (x == NULL){
    return x;
  }
  if (x->esq != NULL){
    return maximo(x->esq);
  }
  else{
    return NULL;
  }
}

int getAltura(No* p){
  if (p == NULL){
    return 0;
  }
  int e = getAltura(p->esq);
  int d = getAltura(p->dir);
  if (e>d){
    return 1+e;
  }
  else{
    return 1+d;
  }
}

int checarAvl(No* x){
  int e = getAltura(x->esq);
  int d = getAltura(x->dir);

  if (e-d > 1 || d-e > 1){
    return 0;
  }
  else{
    return 1;
  }
}


void rotacaoDireita(Arvore* t,No* p){
  No* u = p->esq;

  p->esq = u->dir;
  if(p->esq != NULL){
    p->esq->pai = p;
  }
  u->pai = p->pai;
  u->dir = p;
  if (t->raiz == p){
    t->raiz = u;
  }else if (p->pai->valor > p->valor){
    p->pai->esq = u;
  }
  else{
    p->pai->dir = u;
  }
    p->pai = u;
}
void rotacaoEsquerda(Arvore* t,No* p){
  No* u = p->dir;
  p->dir = u->esq;
  if(p->dir != NULL){
    p->dir->pai = p;
  }
  u->pai = p->pai;
  u->esq = p;
  if (p == t->raiz){
    t->raiz = u;
  }
  else if(p->valor < p->pai->valor){
    p->pai->esq = u;
  }
  else{
    p->pai->dir = u;
  }
  p->pai = u;
}
void rotacaoDuplaDireita(Arvore* t,No* p){
  No* u = p->esq;
  rotacaoEsquerda(t,u);
  rotacaoDireita(t,p);
}
void rotacaoDuplaEsquerda(Arvore* t,No* p){
  No* u = p->dir;
  rotacaoDireita(t,u);
  rotacaoEsquerda(t,p);
}

No* inserir(Arvore* t, No* z){
  No* y = NULL;
  No* x = t->raiz;

  while (x != NULL) {
    y = x;
    if (z->valor < x->valor){
      x = x->esq;
    }
    else{
      x = x->dir;
    }
  }
  z->pai = y;
  if (y == NULL){
    t->raiz = z;
  }
  else if(z->valor < y->valor){
    y->esq = z;
  }
  else{
    y->dir = z;
  }
  No* p = z;
  int flag = checarAvl(p);
  while (flag == 1 && p->pai != NULL){
    p=p->pai;
    flag = checarAvl(p);
  }
  if (checarAvl(p) != 1){
    int e = getAltura(p->esq);
    int d = getAltura(p->dir);
    if (e > d){
      if(p->esq != NULL){
        e = getAltura(p->esq->esq);
        d = getAltura(p->esq->dir);
      }
      else{
        e = 0;
        d = 0;
      }
      if (e < d){
        rotacaoDuplaDireita(t,p);
      }
      else{
        rotacaoDireita(t,p);
      }
    }
    else{
      if (p->dir != NULL) {
        e = getAltura(p->dir->esq);
        d = getAltura(p->dir->dir);
      }
      else{
        e = 0;
        d = 0;
      }
      if(d < e){
        rotacaoDuplaEsquerda(t,p);
      }
      else{
        rotacaoEsquerda(t,p);
      }
    }
  }
}

Arvore* montarArvore(FILE* arquivo){
  int inicio;
  fscanf(arquivo, "%d", &inicio);
  Arvore* arvore = iniciarArvore();
  No* no = criarNo(inicio);
  inserir(arvore,no);
  int n;
  while(fscanf(arquivo, "%d\n", &n) != EOF){
    no = criarNo(n);
    inserir(arvore,no);

  }
  return arvore;
}

void imprimir(No* raiz){
  if (raiz == NULL){
      printf("X");
      return;
  }
  printf(" (");
  printf("%d", raiz->valor);

  if (raiz->esq != NULL && raiz->dir != NULL){
      imprimir(raiz->esq);
      imprimir(raiz->dir);
  } else if (raiz->esq != NULL){
          imprimir(raiz->esq);
          printf("(X)");
  } else if (raiz->dir != NULL){
          printf("(X)");
          imprimir(raiz->dir);
  }
  printf(")");
}

void help(){
  printf("-o <arquivo>          : redireciona a saida para o arquivo\n");
printf("-f <arquivo>           : indica o arquivo que contém os dados a serem adicionados na AVL\n");
printf("-m                     : imprime o menor elemento da AVL\n");
printf("-M                     : imprime o maior elemento da AVL\n");
printf("-a <elemento>          : imprime o antecessor na AVL do elemento ou caso contrário imprime -1\n");
printf("-s <elemento>          : imprime o sucessor na AVL do elemento ou caso contrário imprime -1\n");
}

int main(int argc, char *argv[]){
  if(argc == 1) {
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    return 1;
}

 if(strcmp(argv[1], "-h") == 0 && argc == 2){
    help();
    return 0;
 }

 if(argc > 5){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    return 1;
 }


 if(strcmp(argv[1], "-f") != 0){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    return 1;
 }

char* endereco = argv[2];
FILE* arquivo = fopen(endereco, "r");
if(arquivo == NULL){
    printf("\n \n   ERRO: Arquivo de entrada com problema! \n");
    help();
    return 1;
}
if (argc == 3){
  Arvore* arvore = montarArvore(arquivo);
  imprimir(arvore->raiz);
  fclose(arquivo);
  return 0;

}

if(strcmp(argv[3], "-M") == 0){
    Arvore* arvore = montarArvore(arquivo);
    printf("%d\n", maximo(arvore->raiz)->valor);
    fclose(arquivo);
    return 0;
}

if(strcmp(argv[3], "-m") == 0){
    Arvore* arvore = montarArvore(arquivo);
    printf("%d\n", minimo(arvore->raiz)->valor);
    fclose(arquivo);
    return 0;
}

if(argc < 5){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    fclose(arquivo);
    return 1;
 }


if(strcmp(argv[3], "-a") == 0){
    Arvore* arvore = montarArvore(arquivo);
int num = atoi(argv[4]);
    No* no = buscar(arvore->raiz, num);
    int pr = predecessor(no)->valor;
    printf("%d\n", pr);
    fclose(arquivo);
    return 0;
}

if(strcmp(argv[3], "-s") == 0){
    Arvore* arvore = montarArvore(arquivo);
    int num = atoi(argv[4]);
    No* no = buscar(arvore->raiz, num);
    int s = sucessor(no)->valor;
    printf("%d\n", s);
    fclose(arquivo);
    return 0;
}


if(strcmp(argv[3], "-o") != 0){
    printf("\n \n   ERRO: Parametros invalidos! \n");
    help();
    fclose(arquivo);
    return 1;
}


if(strcmp(argv[3], "-o") == 0){
    char* caminho = argv[4];
    FILE* arquivo_saida = freopen(caminho, "w", stdout);
    if(arquivo_saida == NULL){
        printf("\n \n   ERRO: Arquivo de saida com erro! \n");
        help();
        return 1;
    }
    Arvore* arvore = montarArvore(arquivo);
    fclose(arquivo);
    imprimir(arvore->raiz);
    fclose(arquivo_saida);
    return 0;
}
  return 0;
}
