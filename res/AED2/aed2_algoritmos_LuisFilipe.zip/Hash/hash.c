#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct no{
  int valor;
  struct no* prox;
}No;

typedef struct lista{
  No* inicio;
}Lista;

typedef struct hash{
  Lista* vet[1000];
  int tamanho;
}Hash;

Lista* iniciarLista(){
  Lista* l = malloc(sizeof(Lista));
  l->inicio = NULL;
  return l;
}

No* criarNo(int valor){
  No* no = (No*)malloc(sizeof(No));
  no->valor = valor;
  no->prox = NULL;
  return no;
}

Hash* criarHash(int tamanho){
  Hash* h = malloc(sizeof(Hash));
  h->vet[tamanho];
  h->tamanho = tamanho;
  int i;
  for (i = 0; i < h->tamanho; i++){
    Lista* l = iniciarLista();
    h->vet[i] = l;
  }
  return h;
}

Lista* inserirLista(Lista* l, No* no){
  if (l->inicio == NULL){
    l->inicio = no;
  }
  else{
    no->prox = l->inicio;
    l->inicio = no;
  }
}

int hashNum(float valor,int tamanho){
  // a = 0.55
  float x = abs(valor)*0.55;
  int y = (int) x;
  float mod = x - y;
  float hash = (tamanho*mod);
  int Ihash = (int) hash;
  return Ihash;
}

void inserirHash(Hash* h, int valor){
  No* no = criarNo(valor);
  int pos = hashNum(valor,h->tamanho);
  Lista* l = h->vet[pos];
  inserirLista(l, no);
}

void imprimir(Hash* h){
  int k;
  No* p;
  for (k = 0; k < h->tamanho; k++) {
    printf("%d:", k);
    p = h->vet[k]->inicio;
    while (p != NULL) {
      printf(" %d", p->valor);
      p = p->prox;
    }
    printf("\n");
  }
}

void help(){
  printf("-h : mostra o help\n");
  printf("-o <arquivo> : redireciona a saida para o arquivo\n");
  printf("-f <arquivo> : indica o arquivo que contém os dados a serem adicionados na Hash\n");
  printf("-m <inteiro>: indica o tamanho da hash\n");
}

Hash* montarHash(FILE* arquivo,int tamanho){
  int inicio;
  fscanf(arquivo, "%d", &inicio);
  Hash* h = criarHash(tamanho);
  inserirHash(h,inicio);
  int n;
  while(fscanf(arquivo, "%d\n", &n) != EOF){
    inserirHash(h,n);

  }
  return h;
}

int main(int argc, char *argv[]) {
  if(strcmp(argv[1], "-h") == 0){
    help();
    return 0;
  }
  if (strcmp(argv[1], "-f") == 0 && argc == 3){
    char* endereco = argv[2];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    Hash* h = montarHash(arquivo,11);
    imprimir(h);
    fclose(arquivo);
    free(h);
    return 0;
  }

  if (strcmp(argv[1],"-f")==0 && argc == 5){
    char* endereco = argv[2];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    Hash* h = montarHash(arquivo,11);
    char* caminho = argv[4];
    FILE* arquivo_saida = freopen(caminho, "w", stdout);
    imprimir(h);
    fclose(arquivo);
    fclose(arquivo_saida);
    free(h);
  }

  if (strcmp(argv[1], "-m") == 0 && argc == 5){
    char* endereco = argv[4];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    int tam = atoi(argv[2]);
    Hash* h = montarHash(arquivo,tam);
    imprimir(h);
    fclose(arquivo);
    free(h);
    return 0;
  }

  if (strcmp(argv[1],"-m")==0 && argc == 7){
    char* endereco = argv[4];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    int tam = atoi(argv[2]);
    Hash* h = montarHash(arquivo,tam);
    char* caminho = argv[6];
    FILE* arquivo_saida = freopen(caminho, "w", stdout);
    imprimir(h);
    fclose(arquivo);
    fclose(arquivo_saida);
    free(h);
  }
    return 0;
}
