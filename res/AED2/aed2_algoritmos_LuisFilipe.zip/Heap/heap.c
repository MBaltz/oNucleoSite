#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Heap{
  int vet[1001];
  int tamanho;
  int elementos;
}Heap;

Heap* criarHeap(){
  Heap* heap = malloc(sizeof(Heap));
  heap->tamanho = 1000;
  heap->elementos = 0;
  return heap;
}

int pai(int i){
  return (i/2);
}
int esquerda(int i){
  return 2*i;
}
int direita(int i){
  return (2*i)+1;
}

void maxHeapify(Heap* h, int i){
  int e = esquerda(i);
  int d = direita(i);
  int maior = i;

  if (e <= h->elementos && h->vet[e] > h->vet[i]){
    maior = e;
  }
  if (d <= h->elementos && h->vet[d] > h->vet[maior]){
    maior = d;
  }
  if (maior != i){
    int aux = h->vet[i];
    h->vet[i] = h->vet[maior];
    h->vet[maior] = aux;
    maxHeapify(h,maior);
  }
}

void contruirHeapMax(Heap* h){
  int i;
  for (i = h->elementos/2; i >= 1; i--){
    maxHeapify(h,i);
  }
}

int maximo(Heap* h){
  if (h->elementos == 0){
    return -1;
  }
  return h->vet[1];
}

int extrairMaximo(Heap* h){
  if (h->elementos < 1){
    return -1;
  }
  int max = maximo(h);
  h->vet[1] = h->vet[h->elementos];
  h->elementos -= 1;
  maxHeapify(h,1);
  return max;
}

void inserir(Heap* h,int valor){
  h->elementos += 1;
  h->vet[h->elementos] = valor;
  contruirHeapMax(h);
}

void increaseKey(Heap* h, int i, int chave){
  if (h->vet[i] > chave){
    return;
  }
  h->vet[i] = chave;

  while (i > 1 && h->vet[pai(i)] < h->vet[i]){
    h->vet[i] = h->vet[pai(i)];
    h->vet[pai(i)] = chave;
    i = pai(i);
  }
}

void heapSort(Heap* h){
  contruirHeapMax(h);
  int *vet = h->vet;
  int fim = h->elementos;
  int tam = fim;
  while (fim > 1) {
    int aux = vet[fim];
    vet[fim] = vet[1];
    vet[1] = aux;
    fim--;
    h->elementos -= 1;
    maxHeapify(h,1);
  }
  h->elementos = tam;

}
void imprimir(Heap* h){
  int *heap = h->vet;
  int i;
  for (i = 1; i <= h->elementos; i++){
    if(i == h->elementos){
      printf("%d\n", heap[i]);
    }
    else{
      printf("%d ", heap[i]);
    }
  }
}

void imprimirReverse(Heap* h){
  int *heap = h->vet;
  int i;
  for (i = h->elementos; i >= 1; i--){
    if(i == 1){
      printf("%d\n", heap[i]);
    }
    else{
      printf("%d ", heap[i]);
    }
  }
}
void minHeapify(Heap* h, int i){
  int e = esquerda(i);
  int d = direita(i);
  int menor = i;

  if (e <= h->elementos && h->vet[e] < h->vet[i]){
    menor = e;
  }
  if (d <= h->elementos && h->vet[d] < h->vet[menor]){
    menor = d;
  }
  if (menor != i){
    int aux = h->vet[i];
    h->vet[i] = h->vet[menor];
    h->vet[menor] = aux;
    minHeapify(h,menor);
  }
}

void construirHeapMin(Heap* h){
  for (int i = h->elementos/2; i >= 1; i--){
    minHeapify(h,i);
  }
}

Heap* montarHeap(FILE* arquivo){
  int inicio;
  fscanf(arquivo, "%d", &inicio);
  Heap* h = criarHeap();
  inserir(h,inicio);
  int n;
  while(fscanf(arquivo, "%d\n", &n) != EOF){
    inserir(h,n);

  }
  return h;
}
void help(){
  printf("-h : mostra o help\n");
  printf("-o <arquivo> : redireciona a saida para o arquivo\n");
  printf("-f <arquivo> : indica o arquivo que contém os dados a serem adicionados na Heap\n");
  printf("-m : indica que a estrutura será uma heap mínima\n");
}


int main(int argc, char *argv[]) {
  if(strcmp(argv[1], "-h") == 0){
    help();
    return 0;
  }
  if (strcmp(argv[1], "-f") == 0 && argc == 3){
    char* endereco = argv[2];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    Heap* h = montarHeap(arquivo);
    heapSort(h);
    imprimirReverse(h);
    fclose(arquivo);
    return 0;

  }
  if (strcmp(argv[1], "-m") == 0 && argc == 4){
    char* endereco = argv[3];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    Heap* h = montarHeap(arquivo);
    construirHeapMin(h);
    heapSort(h);
    imprimir(h);
    fclose(arquivo);
    return 0;

  }
  if (argc == 5 && strcmp(argv[1], "-f") == 0){

    char* endereco = argv[2];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    char* caminho = argv[4];
    FILE* arquivo_saida = freopen(caminho, "w", stdout);
    Heap* h = montarHeap(arquivo);
    heapSort(h);
    imprimirReverse(h);
    fclose(arquivo);
    fclose(arquivo_saida);
    return 0;
  }

  if (argc == 6 && strcmp(argv[1], "-m") == 0){

    char* endereco = argv[3];
    FILE* arquivo = fopen(endereco, "r");
    if (arquivo == NULL){
      printf("ERRO: Leitura do arquivo");
      fclose(arquivo);
      return 1;
    }
    char* caminho = argv[5];
    FILE* arquivo_saida = freopen(caminho, "w", stdout);
    Heap* h = montarHeap(arquivo);
    construirHeapMin(h);
    heapSort(h);
    imprimir(h);
    fclose(arquivo);
    fclose(arquivo_saida);
    return 0;
  }


  return 0;
}
